import { useState } from "react";
import { Benefits } from "@/components/Benefits";
import { Booking } from "@/components/Booking";
import { FAQ } from "@/components/FAQ";
import { Footer } from "@/components/Footer";
import { GradeBench } from "@/components/GradeBench";
import { Hero } from "@/components/Hero";
import { Nav } from "@/components/Nav";
import { Pricing } from "@/components/Pricing";
import { Proof } from "@/components/Proof";
import { Services } from "@/components/Services";
import { Testimonials } from "@/components/Testimonials";
import { Work } from "@/components/Work";
import { GrainLayer } from "@/components/ui";

export default function App() {
  const [prefill, setPrefill] = useState("");

  return (
    <div className="relative min-h-screen bg-ink-950 text-bone-100 antialiased">
      <GrainLayer />
      <Nav />
      <main id="main">
        <Hero />
        <Proof />
        <Work />
        <GradeBench />
        <Services />
        <Benefits />
        <Testimonials />
        <Pricing onRequest={setPrefill} />
        <FAQ />
        <Booking prefill={prefill} />
      </main>
      <Footer />
    </div>
  );
}

import { useMemo, useState } from "react";
import { ADDONS, TIERS } from "@/lib/data";
import { scrollToId } from "@/lib/hooks";
import { cn } from "@/utils/cn";
import { Icon } from "./Icon";
import { Reveal, SectionHeading, Timecode } from "./ui";

const ALLOWANCE: Record<string, number> = { cutdown: 6, brand: 20, retainer: 40 };
const BASE_DAYS: Record<string, number> = { cutdown: 5, brand: 10, retainer: 20 };
const OVERAGE_PER_HOUR = 45;

const EVERY_PROJECT = [
  "Same editor, start to delivery",
  "Frame.io review with timestamped notes",
  "Licensed, cleared music",
  "All aspect ratios + platform specs",
  "Project archive & 6-month backup",
  "Fixed price, quoted in writing",
];

const eur = (n: number) =>
  new Intl.NumberFormat("en-IE", { style: "currency", currency: "EUR", maximumFractionDigits: 0 }).format(n);

export function Pricing({ onRequest }: { onRequest: (summary: string) => void }) {
  const [tierId, setTierId] = useState("brand");
  const [hours, setHours] = useState(14);
  const [addons, setAddons] = useState<string[]>(["subs"]);

  const tier = TIERS.find((t) => t.id === tierId)!;
  const allowance = ALLOWANCE[tierId];
  const overageHours = Math.max(0, hours - allowance);
  const addonTotal = ADDONS.filter((a) => addons.includes(a.id)).reduce((s, a) => s + a.price, 0);
  const overageTotal = tierId === "retainer" ? 0 : overageHours * OVERAGE_PER_HOUR;
  const total = tier.price + overageTotal + addonTotal;
  const days = Math.max(3, BASE_DAYS[tierId] - (addons.includes("rush") ? 2 : 0));

  const summary = useMemo(() => {
    const chosen = ADDONS.filter((a) => addons.includes(a.id)).map((a) => a.label);
    return [
      `Scope: ${tier.name} (${eur(tier.price)})`,
      `Footage: ~${hours} hours${overageHours ? ` (+${overageHours}h over allowance)` : ""}`,
      chosen.length ? `Add-ons: ${chosen.join(", ")}` : "Add-ons: none",
      `Estimated total: ${eur(total)} · delivery ~${days} working days`,
    ].join("\n");
  }, [tier, hours, overageHours, addons, total, days]);

  const toggle = (id: string) =>
    setAddons((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));

  return (
    <section id="rates" className="relative overflow-hidden bg-bone-50 py-20 sm:py-28">
      <div aria-hidden="true" className="pointer-events-none absolute inset-0">
        <div className="absolute inset-0 bg-[radial-gradient(55%_45%_at_80%_0%,rgba(79,184,160,0.12),transparent_60%),radial-gradient(50%_40%_at_8%_100%,rgba(232,155,46,0.13),transparent_60%)]" />
        <div className="grain-layer absolute inset-0 opacity-[0.04] mix-blend-multiply" />
      </div>

      <div className="relative mx-auto w-full max-w-[1400px] px-4 sm:px-6 lg:px-10">
        <SectionHeading
          tone="light"
          eyebrow="Rates · flat project pricing"
          title={[
            <>You'll know the number</>,
            <>
              before I press <span className="text-gold-600">record.</span>
            </>,
          ]}
          lead="No hourly meter, no 'it depends' emails. Three ways to work together, one scope estimator so you can see the number move as you change the scope. Every price is EUR, ex-VAT, and fixed once we sign off."
          aside={
            <div className="rounded-[14px] border border-ash/18 bg-white/70 px-5 py-4 backdrop-blur">
              <p className="font-mono text-[10px] tracking-[0.18em] text-ash uppercase">
                Payment terms
              </p>
              <p className="mt-1.5 font-display text-2xl font-bold text-ink-900">50 / 50</p>
              <p className="mt-0.5 text-xs text-ash">half to book the slot, half on delivery</p>
            </div>
          }
        />

        {/* tiers */}
        <div className="mt-14 grid items-start gap-5 lg:grid-cols-3">
          {TIERS.map((t, i) => {
            const featured = !!t.featured;
            const selected = tierId === t.id;
            return (
              <Reveal key={t.id} delay={i * 90} variant="up">
                <article
                  className={cn(
                    "lift group relative h-full overflow-hidden rounded-[18px] border p-6 sm:p-7",
                    featured
                      ? "border-gold-400/45 bg-ink-900 text-bone-100 shadow-[0_44px_90px_-46px_rgba(28,18,6,0.9)] lg:-mt-5 lg:mb-[-1.25rem] lg:p-8"
                      : "border-ash/18 bg-white/72 text-ink-900 backdrop-blur-sm hover:border-ash/40",
                    selected && !featured && "border-gold-500 ring-1 ring-gold-500/40",
                    selected && featured && "ring-2 ring-gold-400/70",
                  )}
                >
                  {featured && (
                    <>
                      <span
                        aria-hidden="true"
                        className="pointer-events-none absolute inset-0 bg-[radial-gradient(80%_55%_at_50%_0%,rgba(242,180,87,0.16),transparent_65%)]"
                      />
                      <span className="absolute top-5 right-5 inline-flex items-center gap-1.5 rounded-full bg-gold-400 px-3 py-1 font-mono text-[9px] tracking-[0.18em] text-ink-950 uppercase">
                        <Icon name="spark" size={11} />
                        Most booked
                      </span>
                    </>
                  )}

                  <p
                    className={cn(
                      "font-mono text-[10px] tracking-[0.2em] uppercase",
                      featured ? "text-gold-400" : "text-gold-600",
                    )}
                  >
                    0{i + 1} · {t.best}
                  </p>
                  <h3
                    className={cn(
                      "mt-3 font-display text-[clamp(1.7rem,3.4vw,2.3rem)] leading-none font-bold tracking-[-0.03em]",
                      featured ? "text-bone-50" : "text-ink-900",
                    )}
                  >
                    {t.name}
                  </h3>
                  <p className={cn("mt-2.5 text-[13.5px]", featured ? "text-smoke" : "text-ash")}>
                    {t.kicker}
                  </p>

                  <div className="mt-6 flex items-end gap-2">
                    <span
                      className={cn(
                        "font-display text-[clamp(2.4rem,5vw,3.2rem)] leading-none font-bold tabular-nums",
                        featured ? "text-gold-400" : "text-ink-900",
                      )}
                    >
                      {eur(t.price)}
                    </span>
                    <span
                      className={cn(
                        "pb-1.5 font-mono text-[10.5px] tracking-[0.14em] uppercase",
                        featured ? "text-smoke/75" : "text-ash/75",
                      )}
                    >
                      {t.unit}
                    </span>
                  </div>

                  <button
                    onClick={() => setTierId(t.id)}
                    aria-pressed={selected}
                    className={cn(
                      "btn-sheen mt-6 inline-flex w-full items-center justify-center gap-2 rounded-full px-5 py-3 text-sm font-semibold transition-all duration-300",
                      featured
                        ? "bg-gold-400 text-ink-950 hover:-translate-y-0.5 hover:bg-gold-300"
                        : "border border-ink-900/20 text-ink-900 hover:-translate-y-0.5 hover:border-ink-900 hover:bg-ink-900 hover:text-bone-50",
                    )}
                  >
                    <span className="relative z-10">
                      {selected ? "Selected for estimate" : `Build with ${t.name}`}
                    </span>
                    <span className="relative z-10">
                      <Icon name={selected ? "check" : "arrowRight"} size={15} strokeWidth={2} />
                    </span>
                  </button>

                  <ul className="mt-7 space-y-2.5">
                    {t.includes.map((inc) => (
                      <li key={inc} className="flex items-start gap-2.5 text-[13.5px] leading-snug">
                        <span
                          className={cn(
                            "mt-[3px] shrink-0",
                            featured ? "text-jade-400" : "text-gold-600",
                          )}
                        >
                          <Icon name="check" size={13} strokeWidth={2.2} />
                        </span>
                        <span className={featured ? "text-bone-200" : "text-ink-800"}>{inc}</span>
                      </li>
                    ))}
                  </ul>

                  <p
                    className={cn(
                      "mt-5 border-t pt-4 text-[12px]",
                      featured
                        ? "border-bone-100/12 text-smoke/65"
                        : "border-ash/16 text-ash/75",
                    )}
                  >
                    <span className="font-mono text-[9.5px] tracking-[0.16em] uppercase">
                      Not included:{" "}
                    </span>
                    {t.not}
                  </p>
                </article>
              </Reveal>
            );
          })}
        </div>

        {/* every project strip */}
        <Reveal delay={80}>
          <ul className="mt-8 grid gap-x-6 gap-y-3 rounded-[14px] border border-ash/16 bg-white/60 px-5 py-5 backdrop-blur sm:grid-cols-2 lg:grid-cols-3">
            {EVERY_PROJECT.map((e) => (
              <li key={e} className="flex items-center gap-2.5 text-[13.5px] text-ink-800">
                <span className="grid size-5 shrink-0 place-items-center rounded-full bg-jade-500/15 text-jade-500">
                  <Icon name="check" size={11} strokeWidth={2.6} />
                </span>
                {e}
              </li>
            ))}
          </ul>
        </Reveal>

        {/* estimator */}
        <Reveal delay={120}>
          <div className="relative mt-6 overflow-hidden rounded-[20px] border border-ink-900/20 bg-ink-950 p-6 sm:p-9">
            <div
              aria-hidden="true"
              className="pointer-events-none absolute inset-0 bg-[radial-gradient(70%_60%_at_15%_0%,rgba(242,180,87,0.14),transparent_60%),radial-gradient(50%_50%_at_95%_100%,rgba(226,96,63,0.12),transparent_60%)]"
            />
            <div className="relative grid gap-10 lg:grid-cols-12 lg:gap-12">
              <div className="lg:col-span-7">
                <div className="flex items-center gap-3">
                  <span className="grid size-9 place-items-center rounded-full bg-gold-400/12 text-gold-400">
                    <Icon name="sliders" size={17} />
                  </span>
                  <div>
                    <h3 className="font-display text-xl leading-none font-bold text-bone-50">
                      Scope estimator
                    </h3>
                    <Timecode className="mt-1.5 block text-smoke/65">
                      Drag, tick, watch the number move
                    </Timecode>
                  </div>
                </div>

                {/* tier switch */}
                <fieldset className="mt-8">
                  <legend className="font-mono text-[10px] tracking-[0.2em] text-smoke/70 uppercase">
                    Base package
                  </legend>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {TIERS.map((t) => (
                      <button
                        key={t.id}
                        onClick={() => setTierId(t.id)}
                        aria-pressed={tierId === t.id}
                        className={cn(
                          "rounded-full border px-4 py-2 text-[13px] font-medium transition-all duration-300",
                          tierId === t.id
                            ? "border-gold-400 bg-gold-400 text-ink-950"
                            : "border-bone-100/15 text-smoke hover:-translate-y-0.5 hover:border-gold-400/50 hover:text-bone-50",
                        )}
                      >
                        {t.name}
                        <span className="ml-2 font-mono text-[10px] opacity-70">{eur(t.price)}</span>
                      </button>
                    ))}
                  </div>
                </fieldset>

                {/* hours slider */}
                <div className="mt-8">
                  <div className="flex items-end justify-between gap-4">
                    <label
                      htmlFor="hours"
                      className="font-mono text-[10px] tracking-[0.2em] text-smoke/70 uppercase"
                    >
                      Footage volume
                    </label>
                    <span className="font-display text-2xl leading-none font-bold text-bone-50 tabular-nums">
                      {hours}
                      <span className="ml-1 font-mono text-[11px] tracking-[0.12em] text-smoke uppercase">
                        hrs
                      </span>
                    </span>
                  </div>
                  <input
                    id="hours"
                    type="range"
                    min={2}
                    max={40}
                    step={1}
                    value={hours}
                    onChange={(e) => setHours(Number(e.target.value))}
                    className="range-gold mt-4 w-full cursor-pointer bg-bone-100/15 accent-gold-400 outline-none"
                    style={{
                      background: `linear-gradient(to right, var(--color-gold-400) ${((hours - 2) / 38) * 100}%, rgba(247,243,236,0.15) ${((hours - 2) / 38) * 100}%)`,
                    }}
                  />
                  <div className="mt-2.5 flex justify-between font-mono text-[9.5px] tracking-[0.14em] text-smoke/55 uppercase">
                    <span>2 hrs · one interview</span>
                    <span>
                      allowance {allowance} hrs
                      {overageHours > 0 && tierId !== "retainer" && (
                        <span className="text-ember-400"> · +{overageHours}h over</span>
                      )}
                    </span>
                    <span>40 hrs · two-cam doc</span>
                  </div>
                </div>

                {/* addons */}
                <fieldset className="mt-8">
                  <legend className="font-mono text-[10px] tracking-[0.2em] text-smoke/70 uppercase">
                    Add-ons
                  </legend>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {ADDONS.map((a) => {
                      const on = addons.includes(a.id);
                      return (
                        <button
                          key={a.id}
                          onClick={() => toggle(a.id)}
                          aria-pressed={on}
                          className={cn(
                            "inline-flex items-center gap-2 rounded-full border px-3.5 py-2 text-[12.5px] transition-all duration-300",
                            on
                              ? "border-jade-400/70 bg-jade-500/14 text-bone-50"
                              : "border-bone-100/14 text-smoke hover:-translate-y-0.5 hover:border-jade-400/45 hover:text-bone-100",
                          )}
                        >
                          <span
                            className={cn(
                              "grid size-4 place-items-center rounded-full border transition-colors",
                              on ? "border-jade-400 bg-jade-400 text-ink-950" : "border-smoke/45",
                            )}
                          >
                            {on && <Icon name="check" size={10} strokeWidth={3} />}
                          </span>
                          {a.label}
                          <span className="font-mono text-[10px] text-smoke/70">
                            +{eur(a.price)}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </fieldset>
              </div>

              {/* total */}
              <div className="lg:col-span-5">
                <div className="panel sticky top-28 rounded-[16px] p-6">
                  <Timecode className="text-gold-400">YOUR ESTIMATE</Timecode>
                  <p className="mt-4 font-display text-[clamp(2.6rem,7vw,3.6rem)] leading-none font-bold text-bone-50 tabular-nums">
                    {eur(total)}
                  </p>
                  <p className="mt-2 text-[13px] text-smoke">
                    {tier.name} · {hours} hrs footage · delivery in ~{days} working days
                  </p>

                  <dl className="mt-6 space-y-2.5 border-t border-bone-100/10 pt-5 text-[13px]">
                    <div className="flex justify-between gap-4">
                      <dt className="text-smoke">Base package</dt>
                      <dd className="text-bone-100 tabular-nums">{eur(tier.price)}</dd>
                    </div>
                    <div className="flex justify-between gap-4">
                      <dt className="text-smoke">
                        Extra footage{" "}
                        <span className="font-mono text-[10px] text-smoke/60">
                          ({overageHours}h × {eur(OVERAGE_PER_HOUR)})
                        </span>
                      </dt>
                      <dd className="text-bone-100 tabular-nums">
                        {overageTotal ? eur(overageTotal) : "—"}
                      </dd>
                    </div>
                    <div className="flex justify-between gap-4">
                      <dt className="text-smoke">Add-ons ({addons.length})</dt>
                      <dd className="text-bone-100 tabular-nums">
                        {addonTotal ? eur(addonTotal) : "—"}
                      </dd>
                    </div>
                    <div className="flex justify-between gap-4 border-t border-bone-100/10 pt-3">
                      <dt className="font-medium text-bone-100">Deposit to book</dt>
                      <dd className="font-display text-lg font-bold text-gold-400 tabular-nums">
                        {eur(Math.round(total / 2))}
                      </dd>
                    </div>
                  </dl>

                  <button
                    onClick={() => {
                      onRequest(summary);
                      window.setTimeout(() => scrollToId("book"), 60);
                    }}
                    className="btn-sheen group mt-6 inline-flex w-full items-center justify-center gap-2 rounded-full bg-gold-400 px-6 py-3.5 text-sm font-semibold text-ink-950 transition-all duration-300 hover:-translate-y-0.5 hover:bg-gold-300 hover:shadow-[0_18px_44px_-18px_rgba(242,180,87,1)]"
                  >
                    <span className="relative z-10">Request this scope</span>
                    <span className="relative z-10 transition-transform duration-300 group-hover:translate-x-1">
                      <Icon name="arrowRight" size={16} strokeWidth={2} />
                    </span>
                  </button>
                  <p className="mt-3.5 text-center font-mono text-[9.5px] tracking-[0.14em] text-smoke/60 uppercase">
                    Estimate lands pre-filled in the brief · reply within 4 business hours
                  </p>
                </div>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

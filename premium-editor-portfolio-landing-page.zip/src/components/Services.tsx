import { useRef, useState } from "react";
import { SERVICES } from "@/lib/data";
import { scrollToId, useFinePointer, useReducedMotion } from "@/lib/hooks";
import { cn } from "@/utils/cn";
import { Icon } from "./Icon";
import { Reveal, SectionHeading } from "./ui";

const TOOL_RAIL = [
  "Premiere Pro",
  "DaVinci Resolve",
  "After Effects",
  "Pro Tools",
  "Frame.io",
  "iZotope RX",
  "Cavalry",
  "Shotgun",
  "Audition",
  "Media Encoder",
];

export function Services() {
  const [open, setOpen] = useState<number | null>(0);
  const [hover, setHover] = useState<number | null>(null);
  const fine = useFinePointer();
  const reduced = useReducedMotion();
  const preview = useRef<HTMLDivElement | null>(null);

  const showPreview = fine && !reduced;

  const movePreview = (e: React.PointerEvent) => {
    if (!showPreview || !preview.current) return;
    preview.current.style.transform = `translate3d(${e.clientX + 26}px, ${e.clientY - 90}px, 0)`;
  };

  return (
    <section id="services" className="relative overflow-hidden bg-bone-50 py-20 sm:py-28">
      {/* paper texture + ambient */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-0">
        <div className="absolute inset-0 bg-[radial-gradient(70%_50%_at_85%_0%,rgba(232,155,46,0.12),transparent_65%),radial-gradient(50%_45%_at_5%_95%,rgba(79,184,160,0.1),transparent_60%)]" />
        <div className="grain-layer absolute inset-0 opacity-[0.04] mix-blend-multiply" />
      </div>

      <div className="relative mx-auto w-full max-w-[1400px] px-4 sm:px-6 lg:px-10">
        <SectionHeading
          tone="light"
          eyebrow="Services · what actually happens"
          title={[
            <>Six things I do</>,
            <>
              to your <span className="text-gold-600">footage.</span>
            </>,
          ]}
          lead="One person from ingest to delivery — no agency handoff, no outsourced grade. Pick a lane or take the whole post pipeline; every project is scoped in writing before the first render."
          aside={
            <div className="flex flex-col items-start gap-3 lg:items-end">
              <div className="rounded-[14px] border border-ash/18 bg-white/70 px-5 py-4 backdrop-blur">
                <p className="font-mono text-[10px] tracking-[0.18em] text-ash uppercase">
                  Typical engagement
                </p>
                <p className="mt-1.5 font-display text-2xl font-bold text-ink-900">10 days</p>
                <p className="mt-0.5 text-xs text-ash">brief → broadcast-ready master</p>
              </div>
              <button
                onClick={() => scrollToId("rates")}
                className="group inline-flex items-center gap-2 font-mono text-[11px] tracking-[0.16em] text-ink-900/70 uppercase transition-colors hover:text-gold-600"
              >
                See rates
                <span className="transition-transform duration-300 group-hover:translate-x-1">
                  <Icon name="arrowRight" size={14} />
                </span>
              </button>
            </div>
          }
        />

        {/* accordion */}
        <div className="mt-14 border-t border-ink-900/12">
          {SERVICES.map((s, i) => {
            const isOpen = open === i;
            return (
              <Reveal key={s.no} delay={i * 55}>
                <div
                  className={cn(
                    "group relative border-b border-ink-900/12 transition-colors duration-500",
                    isOpen ? "bg-white/55" : "hover:bg-white/35",
                  )}
                  onPointerMove={movePreview}
                  onPointerEnter={() => showPreview && setHover(i)}
                  onPointerLeave={() => showPreview && setHover(null)}
                >
                  <span
                    aria-hidden="true"
                    className={cn(
                      "absolute inset-y-0 left-0 w-[3px] origin-top bg-gold-500 transition-transform duration-500",
                      isOpen ? "scale-y-100" : "scale-y-0 group-hover:scale-y-100",
                    )}
                  />
                  <h3>
                    <button
                      onClick={() => setOpen(isOpen ? null : i)}
                      aria-expanded={isOpen}
                      aria-controls={`svc-panel-${s.no}`}
                      className="flex w-full cursor-pointer items-center gap-4 px-2 py-6 text-left sm:gap-7 sm:px-6 sm:py-7"
                    >
                      <span
                        className={cn(
                          "font-mono text-[11px] tracking-[0.14em] transition-colors duration-300",
                          isOpen ? "text-gold-600" : "text-ash/60 group-hover:text-gold-600",
                        )}
                      >
                        {s.no}
                      </span>
                      <span className="min-w-0 flex-1">
                        <span
                          className={cn(
                            "block font-display text-[clamp(1.35rem,3.4vw,2.15rem)] leading-[1.05] font-bold tracking-[-0.03em] transition-colors duration-300",
                            isOpen ? "text-ink-900" : "text-ink-900/78 group-hover:text-ink-900",
                          )}
                        >
                          {s.title}
                        </span>
                        <span className="mt-1.5 hidden font-mono text-[10px] tracking-[0.18em] text-ash/70 uppercase sm:block">
                          {s.tag}
                        </span>
                      </span>
                      <span className="hidden shrink-0 font-mono text-[10.5px] tracking-[0.14em] text-ash uppercase md:block">
                        {s.turnaround}
                      </span>
                      <span
                        className={cn(
                          "grid size-9 shrink-0 place-items-center rounded-full border transition-all duration-500",
                          isOpen
                            ? "rotate-45 border-gold-500 bg-gold-500 text-ink-950"
                            : "border-ash/25 text-ash group-hover:border-gold-500 group-hover:text-gold-600",
                        )}
                      >
                        <Icon name="plus" size={15} strokeWidth={1.8} />
                      </span>
                    </button>
                  </h3>

                  <div
                    id={`svc-panel-${s.no}`}
                    role="region"
                    className={cn(
                      "grid transition-[grid-template-rows,opacity] duration-[600ms] ease-[cubic-bezier(0.16,1,0.3,1)]",
                      isOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0",
                    )}
                  >
                    <div className="overflow-hidden">
                      <div className="grid gap-8 px-2 pb-9 sm:px-6 lg:grid-cols-12 lg:gap-10">
                        <div className="lg:col-span-7">
                          <p className="max-w-xl text-[1.02rem] leading-relaxed text-ash">
                            {s.blurb}
                          </p>
                          <ul className="mt-6 grid gap-2.5 sm:grid-cols-2">
                            {s.deliverables.map((d) => (
                              <li key={d} className="flex items-start gap-2.5 text-sm text-ink-800">
                                <span className="mt-[3px] shrink-0 text-gold-600">
                                  <Icon name="check" size={14} strokeWidth={2} />
                                </span>
                                {d}
                              </li>
                            ))}
                          </ul>
                        </div>
                        <div className="lg:col-span-5">
                          <div className="rounded-[14px] border border-ash/15 bg-white/80 p-5">
                            <p className="font-mono text-[10px] tracking-[0.18em] text-ash uppercase">
                              Tools in the chain
                            </p>
                            <div className="mt-3.5 flex flex-wrap gap-2">
                              {s.tools.map((t) => (
                                <span
                                  key={t}
                                  className="rounded-full border border-ink-900/12 bg-bone-100/70 px-3 py-1.5 font-mono text-[10.5px] tracking-[0.08em] text-ink-800"
                                >
                                  {t}
                                </span>
                              ))}
                            </div>
                            <div className="mt-5 flex items-center justify-between border-t border-ash/12 pt-4">
                              <span className="font-mono text-[10px] tracking-[0.16em] text-ash uppercase">
                                Turnaround
                              </span>
                              <span className="font-display text-base font-bold text-ink-900">
                                {s.turnaround}
                              </span>
                            </div>
                            <button
                              onClick={() => scrollToId("book")}
                              className="group mt-5 inline-flex w-full items-center justify-center gap-2 rounded-full bg-ink-900 px-5 py-3 text-sm font-semibold text-bone-50 transition-all duration-300 hover:-translate-y-0.5 hover:bg-gold-500 hover:text-ink-950"
                            >
                              Scope this with me
                              <span className="transition-transform duration-300 group-hover:translate-x-1">
                                <Icon name="arrowRight" size={15} />
                              </span>
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </Reveal>
            );
          })}
        </div>

        {/* tool rail */}
        <Reveal delay={120}>
          <div className="mt-12 flex flex-wrap items-center gap-2.5">
            <span className="mr-2 font-mono text-[10px] tracking-[0.2em] text-ash uppercase">
              Suite stack
            </span>
            {TOOL_RAIL.map((t) => (
              <span
                key={t}
                className="lift cursor-default rounded-full border border-ash/18 px-3.5 py-1.5 text-[12.5px] font-medium text-ink-800/80 hover:-translate-y-1 hover:border-gold-500 hover:bg-white hover:text-ink-900 hover:shadow-[0_10px_24px_-16px_rgba(0,0,0,0.6)]"
              >
                {t}
              </span>
            ))}
          </div>
        </Reveal>
      </div>

      {/* cursor-follow preview */}
      {showPreview && (
        <div
          ref={preview}
          aria-hidden="true"
          className={cn(
            "pointer-events-none fixed top-0 left-0 z-30 hidden h-[150px] w-[230px] overflow-hidden rounded-[10px] border border-bone-100/20 shadow-[0_30px_70px_-30px_rgba(0,0,0,0.9)] transition-opacity duration-300 lg:block",
            hover !== null ? "opacity-100" : "opacity-0",
          )}
        >
          {SERVICES.map((s, i) => (
            <img
              key={s.no}
              src={s.image}
              alt=""
              loading="lazy"
              className={cn(
                "absolute inset-0 size-full object-cover transition-opacity duration-300",
                hover === i ? "opacity-100" : "opacity-0",
              )}
            />
          ))}
          <span className="absolute inset-0 bg-gradient-to-t from-ink-950/70 via-transparent to-transparent" />
          <span className="absolute bottom-2.5 left-3 font-mono text-[9.5px] tracking-[0.18em] text-bone-100 uppercase">
            {hover !== null ? SERVICES[hover].tag : ""}
          </span>
        </div>
      )}
    </section>
  );
}

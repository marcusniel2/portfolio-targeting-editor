import { useEffect, useRef, useState } from "react";
import { GRADES, IMG } from "@/lib/data";
import { useInView, useReducedMotion } from "@/lib/hooks";
import { cn } from "@/utils/cn";
import { Icon } from "./Icon";
import { Reveal, SectionHeading, Timecode } from "./ui";

const SCOPES = [
  { k: "Colour space", v: "Rec.709 · ACEScct" },
  { k: "Node count", v: "6 serial + 2 parallel" },
  { k: "Grain", v: "35mm fine · 8% opacity" },
  { k: "Legal range", v: "64–940 · broadcast safe" },
];

export function GradeBench() {
  const [pos, setPos] = useState(38);
  const [preset, setPreset] = useState(1);
  const [dragging, setDragging] = useState(false);
  const boxRef = useRef<HTMLDivElement | null>(null);
  const reduced = useReducedMotion();
  const { ref: viewRef, inView } = useInView<HTMLDivElement>({ threshold: 0.35 });
  const swept = useRef(false);

  /* one welcome sweep when it first scrolls into view */
  useEffect(() => {
    if (!inView || swept.current || reduced) return;
    swept.current = true;
    let raf = 0;
    const start = performance.now();
    const from = 38;
    const to = 74;
    const dur = 2000;
    const tick = (t: number) => {
      const p = Math.min(1, (t - start) / dur);
      const e = 1 - Math.pow(1 - p, 3);
      setPos(from + (to - from) * e);
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [inView, reduced]);

  const fromClientX = (clientX: number) => {
    const el = boxRef.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    setPos(Math.min(98, Math.max(2, ((clientX - r.left) / r.width) * 100)));
  };

  useEffect(() => {
    if (!dragging) return;
    const move = (e: PointerEvent) => fromClientX(e.clientX);
    const up = () => setDragging(false);
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", up);
    return () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      window.removeEventListener("pointercancel", up);
    };
  }, [dragging]);

  const active = GRADES[preset];
  const log = GRADES[0];

  return (
    <section id="grade" className="relative overflow-hidden border-y border-bone-100/10 bg-ink-900 py-20 sm:py-28">
      <div aria-hidden="true" className="pointer-events-none absolute inset-0">
        <div className="absolute inset-0 bg-[radial-gradient(55%_50%_at_50%_0%,rgba(79,184,160,0.09),transparent_65%)]" />
      </div>

      <div className="relative mx-auto w-full max-w-[1400px] px-4 sm:px-6 lg:px-10">
        <SectionHeading
          eyebrow="The grade bench · interactive"
          title={[
            <>
              Same frame. <span className="text-jade-400">Flat</span> on the left,
            </>,
            <>intentional on the right.</>,
          ]}
          lead="This is the part clients rarely see and always feel. Drag the handle across the frame, then swap the LUT to watch the same shot change genre. Every project ships with a look built this deliberately."
        />

        <div className="mt-12 grid gap-8 lg:grid-cols-12 lg:gap-10">
          {/* viewer */}
          <Reveal variant="scale" className="lg:col-span-8">
            <div ref={viewRef} className="relative">
              <div
                ref={boxRef}
                className="relative aspect-[16/10] w-full cursor-ew-resize touch-none overflow-hidden rounded-[14px] border border-bone-100/12 bg-ink-950 select-none sm:aspect-[16/9]"
                onPointerDown={(e) => {
                  setDragging(true);
                  fromClientX(e.clientX);
                }}
              >
                {/* graded (right / base) */}
                <img
                  src={IMG.grade}
                  alt="Frame with the selected creative grade applied"
                  loading="lazy"
                  className="absolute inset-0 size-full object-cover"
                  style={{ filter: active.filter, transition: "filter .7s ease" }}
                />
                {/* log (left / clipped) */}
                <img
                  src={IMG.grade}
                  alt=""
                  aria-hidden="true"
                  loading="lazy"
                  className="absolute inset-0 size-full object-cover"
                  style={{ filter: log.filter, clipPath: `inset(0 ${100 - pos}% 0 0)` }}
                />

                {/* overlays */}
                <span className="pointer-events-none absolute inset-0 bg-[radial-gradient(110%_80%_at_50%_0%,transparent_45%,rgba(12,10,9,0.6)_100%)]" />
                <span
                  aria-hidden="true"
                  className="pointer-events-none absolute inset-y-0 w-px bg-bone-50/85 shadow-[0_0_20px_3px_rgba(247,243,236,0.4)]"
                  style={{ left: `${pos}%` }}
                />

                {/* labels */}
                <span className="pointer-events-none absolute top-3.5 left-3.5 rounded-full border border-bone-100/15 bg-ink-950/65 px-3 py-1.5 font-mono text-[9.5px] tracking-[0.18em] text-bone-100/80 uppercase backdrop-blur-md sm:top-4 sm:left-4">
                  {log.name} · {log.note}
                </span>
                <span className="pointer-events-none absolute top-3.5 right-3.5 rounded-full border border-gold-400/35 bg-ink-950/65 px-3 py-1.5 font-mono text-[9.5px] tracking-[0.18em] text-gold-300 uppercase backdrop-blur-md sm:top-4 sm:right-4">
                  {active.name}
                </span>
                <span className="pointer-events-none absolute bottom-3.5 left-4 font-mono text-[9.5px] tracking-[0.18em] text-bone-100/55 uppercase">
                  Node 04 · print film emulation
                </span>

                {/* handle (keyboard accessible) */}
              <div
                role="slider"
                tabIndex={0}
                aria-label="Reveal the graded half of the frame"
                aria-valuemin={0}
                aria-valuemax={100}
                aria-valuenow={Math.round(pos)}
                aria-valuetext={`${Math.round(pos)}% graded, showing ${active.name}`}
                onKeyDown={(e) => {
                  const s = e.shiftKey ? 10 : 3;
                  if (e.key === "ArrowRight" || e.key === "ArrowUp") {
                    e.preventDefault();
                    setPos((p) => Math.min(98, p + s));
                  } else if (e.key === "ArrowLeft" || e.key === "ArrowDown") {
                    e.preventDefault();
                    setPos((p) => Math.max(2, p - s));
                  }
                }}
                className="absolute top-1/2 z-20 grid size-12 -translate-x-1/2 -translate-y-1/2 cursor-grab place-items-center rounded-full border border-gold-400/60 bg-ink-950/80 text-gold-300 shadow-[0_10px_36px_-10px_rgba(0,0,0,1)] backdrop-blur-md transition-[box-shadow,border-color] duration-300 hover:border-gold-400 focus-visible:border-gold-400 active:cursor-grabbing"
                style={{ left: `${pos}%` }}
              >
                <span className="absolute inset-0 rounded-full border border-gold-400/40 animate-pulse-ring" />
                  <Icon name="drag" size={19} strokeWidth={1.6} />
                </div>
              </div>

              <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
                <Timecode className="text-smoke/60">
                  Drag the handle · arrow keys nudge · shift = faster
                </Timecode>
                <Timecode className="text-jade-400/90">
                  {Math.round(pos)}% GRADED · {Math.round(100 - pos)}% LOG
                </Timecode>
              </div>
            </div>
          </Reveal>

          {/* presets + scopes */}
          <div className="lg:col-span-4">
            <Reveal variant="right" delay={120}>
              <div className="panel rounded-[16px] p-5 sm:p-6">
                <div className="flex items-center justify-between">
                  <Timecode className="text-gold-400">LUT BANK</Timecode>
                  <span className="font-mono text-[9.5px] tracking-[0.16em] text-smoke/55 uppercase">
                    {String(GRADES.length).padStart(2, "0")} looks
                  </span>
                </div>

                <div className="mt-4 space-y-2">
                  {GRADES.map((g, i) => {
                    const on = preset === i;
                    return (
                      <button
                        key={g.id}
                        onClick={() => setPreset(i)}
                        aria-pressed={on}
                        className={cn(
                          "group flex w-full items-center gap-3 rounded-[11px] border px-3.5 py-3 text-left transition-all duration-300",
                          on
                            ? "border-gold-400/70 bg-gold-400/12"
                            : "border-bone-100/10 bg-ink-950/40 hover:-translate-y-0.5 hover:border-gold-400/40 hover:bg-ink-950/70",
                        )}
                      >
                        <span
                          className="size-9 shrink-0 overflow-hidden rounded-[7px] border border-bone-100/12"
                          aria-hidden="true"
                        >
                          <img
                            src={IMG.grade}
                            alt=""
                            loading="lazy"
                            className="size-full object-cover"
                            style={{ filter: g.filter }}
                          />
                        </span>
                        <span className="min-w-0 flex-1">
                          <span
                            className={cn(
                              "block font-display text-[0.98rem] leading-tight font-bold",
                              on ? "text-gold-300" : "text-bone-100",
                            )}
                          >
                            {g.name}
                          </span>
                          <span className="mt-0.5 block truncate font-mono text-[9.5px] tracking-[0.12em] text-smoke/65 uppercase">
                            {g.note}
                          </span>
                        </span>
                        <span
                          className={cn(
                            "shrink-0 transition-all duration-300",
                            on ? "scale-100 text-gold-400" : "scale-75 text-smoke/30 group-hover:text-smoke/70",
                          )}
                        >
                          <Icon name={on ? "check" : "arrowRight"} size={15} strokeWidth={2} />
                        </span>
                      </button>
                    );
                  })}
                </div>

                <dl className="mt-6 space-y-2.5 border-t border-bone-100/10 pt-5">
                  {SCOPES.map((s) => (
                    <div key={s.k} className="flex items-baseline justify-between gap-4">
                      <dt className="font-mono text-[9.5px] tracking-[0.16em] text-smoke/60 uppercase">
                        {s.k}
                      </dt>
                      <dd className="text-right text-[12.5px] text-bone-200">{s.v}</dd>
                    </div>
                  ))}
                </dl>

                <p className="mt-5 rounded-[11px] border border-jade-500/20 bg-jade-500/8 px-3.5 py-3 text-[12.5px] leading-relaxed text-bone-200">
                  Your LUT bank is delivered with the master — so every film your team cuts next
                  year starts on-brand.
                </p>
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}

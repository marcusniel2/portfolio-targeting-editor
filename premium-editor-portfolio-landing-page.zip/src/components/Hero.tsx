import { memo, useEffect, useMemo, useRef, useState } from "react";
import { BRAND, IMG, STATS } from "@/lib/data";
import {
  scrollToId,
  useFinePointer,
  useInView,
  useReducedMotion,
} from "@/lib/hooks";
import { cn } from "@/utils/cn";
import { Icon } from "./Icon";
import { Button, Eyebrow, MaskLines, Reveal } from "./ui";

/* deterministic pseudo-random for the waveform */
function wave(n: number, seed = 7) {
  return Array.from({ length: n }, (_, i) => {
    const x = Math.sin((i + seed) * 12.9898) * 43758.5453;
    const f = x - Math.floor(x);
    const g = Math.sin(i * 0.34) * 0.5 + 0.5;
    return Math.round(18 + (f * 0.55 + g * 0.45) * 82);
  });
}

const CLIPS = [
  { w: 13, c: "bg-gold-400/85" },
  { w: 8, c: "bg-ember-500/80" },
  { w: 19, c: "bg-jade-500/75" },
  { w: 6, c: "bg-gold-600/80" },
  { w: 17, c: "bg-bone-200/55" },
  { w: 10, c: "bg-ember-400/70" },
  { w: 14, c: "bg-jade-400/60" },
  { w: 13, c: "bg-gold-400/60" },
];

const TOTAL_SECONDS = 148; // 02:28 reel
const FPS = 24;

function timecode(t: number) {
  const total = t * TOTAL_SECONDS;
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = Math.floor(total % 60);
  const f = Math.floor((total - Math.floor(total)) * FPS);
  const p = (n: number) => String(n).padStart(2, "0");
  return `${p(h)}:${p(m)}:${p(s)}:${p(f)}`;
}

/* ------------------------------------------------------------------ */
/* Scrub viewer                                                        */
/* ------------------------------------------------------------------ */

const ScrubViewer = memo(function ScrubViewer() {
  const frames = IMG.reel;
  const reduced = useReducedMotion();
  const fine = useFinePointer();
  const { ref: viewRef, inView } = useInView<HTMLDivElement>({ threshold: 0.2 });
  const [t, setT] = useState(0.12);
  const dragging = useRef(false);
  const hovering = useRef(false);
  const inViewRef = useRef(false);
  const barRef = useRef<HTMLDivElement | null>(null);
  const heights = useMemo(() => wave(72), []);

  useEffect(() => {
    inViewRef.current = inView;
  }, [inView]);

  useEffect(() => {
    if (reduced) return;
    let raf = 0;
    let last = performance.now();
    let acc = 0;
    const loop = (now: number) => {
      const dt = now - last;
      last = now;
      if (!dragging.current && !hovering.current && inViewRef.current) {
        // throttle to ~18fps: keeps the timecode alive without churning the DOM
        acc += dt;
        if (acc >= 55) {
          setT((prev) => (prev + acc / 16000) % 1);
          acc = 0;
        }
      } else {
        acc = 0;
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [reduced]);

  const setFromClientX = (clientX: number) => {
    const el = barRef.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    setT(Math.min(0.9999, Math.max(0, (clientX - r.left) / r.width)));
  };

  useEffect(() => {
    const move = (e: PointerEvent) => {
      if (dragging.current) setFromClientX(e.clientX);
    };
    const up = () => {
      dragging.current = false;
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", up);
    return () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      window.removeEventListener("pointercancel", up);
    };
  }, []);

  const idx = Math.min(frames.length - 1, Math.floor(t * frames.length));
  const tc = timecode(t);
  const played = heights.map((_, i) => i / heights.length <= t);

  return (
    <div ref={viewRef} className="relative">
      {/* corner brackets */}
      {[
        "-top-2 -left-2 border-t border-l",
        "-top-2 -right-2 border-t border-r",
        "-bottom-2 -left-2 border-b border-l",
        "-bottom-2 -right-2 border-b border-r",
      ].map((c) => (
        <span
          key={c}
          aria-hidden="true"
          className={cn("absolute size-5 border-gold-400/45 pointer-events-none z-20", c)}
        />
      ))}

      <div className="relative overflow-hidden rounded-[14px] border border-bone-100/12 bg-ink-900 shadow-[0_50px_120px_-50px_rgba(0,0,0,1)]">
        {/* frame stack */}
        <div className="relative aspect-[16/11] w-full overflow-hidden bg-ink-950 sm:aspect-[16/10]">
          <div className={cn("absolute inset-0", !reduced && "animate-kenburns")}>
            {frames.map((src, i) => (
              <img
                key={src}
                src={src}
                alt=""
                aria-hidden={i !== idx}
                loading={i < 2 ? "eager" : "lazy"}
                decoding="async"
                className={cn(
                  "absolute inset-0 size-full object-cover transition-opacity duration-500 ease-out",
                  i === idx ? "opacity-100" : "opacity-0",
                )}
              />
            ))}
          </div>
          <div className="absolute inset-0 bg-[radial-gradient(120%_90%_at_50%_0%,transparent_35%,rgba(12,10,9,0.72)_100%)]" />
          <div className="absolute inset-0 bg-gradient-to-t from-ink-950 via-ink-950/10 to-ink-950/45" />

          {/* HUD top */}
          <div className="absolute inset-x-0 top-0 flex items-start justify-between gap-3 p-3 sm:p-4">
            <div className="flex items-center gap-2 rounded-full border border-bone-100/12 bg-ink-950/55 px-2.5 py-1.5 backdrop-blur-md">
              <span className="size-1.5 rounded-full bg-ember-500 animate-blink" />
              <span className="font-mono text-[9.5px] tracking-[0.18em] text-bone-100/85 uppercase">
                A012_C0{idx + 1}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className="hidden rounded-full border border-bone-100/12 bg-ink-950/55 px-2.5 py-1.5 font-mono text-[9.5px] tracking-[0.16em] text-bone-100/70 uppercase backdrop-blur-md sm:inline">
                4K · 23.976 · Rec.709
              </span>
              <span className="rounded-full border border-gold-400/30 bg-ink-950/60 px-2.5 py-1.5 font-mono text-[10px] tracking-[0.1em] text-gold-300 tabular-nums backdrop-blur-md">
                {tc}
              </span>
            </div>
          </div>

          {/* HUD bottom */}
          <div className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-4 p-3 sm:p-4">
            <div>
              <p className="font-mono text-[9.5px] tracking-[0.22em] text-gold-400/90 uppercase">
                The 2026 reel
              </p>
              <p className="mt-1 font-display text-lg font-bold text-bone-50 sm:text-xl">
                Night Work · 02:28
              </p>
            </div>
            <div className="hidden items-end gap-[3px] sm:flex" aria-hidden="true">
              {[0, 1, 2, 3, 4].map((i) => (
                <span
                  key={i}
                  className="eq-bar w-[3px] rounded-full bg-jade-400/85"
                  style={{ height: `${12 + i * 4}px`, animationDelay: `${i * 0.16}s` }}
                />
              ))}
            </div>
          </div>
        </div>

        {/* timeline */}
        <div className="border-t border-bone-100/10 bg-ink-900/85 px-3 py-3 sm:px-4 sm:py-4">
          <div
            ref={barRef}
            role="slider"
            tabIndex={0}
            aria-label="Scrub the reel timeline"
            aria-valuemin={0}
            aria-valuemax={100}
            aria-valuenow={Math.round(t * 100)}
            aria-valuetext={`${tc} of ${timecode(1)}`}
            className="group relative cursor-ew-resize touch-none select-none outline-none"
            onPointerDown={(e) => {
              dragging.current = true;
              (e.currentTarget as HTMLElement).setPointerCapture?.(e.pointerId);
              setFromClientX(e.clientX);
            }}
            onPointerMove={(e) => {
              if (!dragging.current && fine && !reduced) {
                hovering.current = true;
                setFromClientX(e.clientX);
              }
            }}
            onPointerLeave={() => {
              hovering.current = false;
            }}
            onKeyDown={(e) => {
              const step = e.shiftKey ? 0.08 : 0.02;
              if (e.key === "ArrowRight" || e.key === "ArrowUp") {
                e.preventDefault();
                hovering.current = true;
                setT((p) => Math.min(0.9999, p + step));
              } else if (e.key === "ArrowLeft" || e.key === "ArrowDown") {
                e.preventDefault();
                hovering.current = true;
                setT((p) => Math.max(0, p - step));
              } else if (e.key === "Home") {
                e.preventDefault();
                setT(0);
              } else if (e.key === "End") {
                e.preventDefault();
                setT(0.999);
              }
            }}
          >
            {/* clip track */}
            <div className="flex h-7 gap-[2px] overflow-hidden rounded-[5px] border border-bone-100/10 bg-ink-950/70 p-[2px]">
              {CLIPS.map((c, i) => (
                <span
                  key={i}
                  className={cn(
                    "h-full rounded-[2px] transition-all duration-300",
                    c.c,
                    i * 12 <= t * 100 && i * 12 + CLIPS[i].w * 0.5 > t * 100
                      ? "brightness-125"
                      : "brightness-100",
                  )}
                  style={{ width: `${c.w}%` }}
                />
              ))}
            </div>

            {/* waveform */}
            <div className="mt-2 flex h-8 items-end gap-[2px]" aria-hidden="true">
              {heights.map((h, i) => (
                <span
                  key={i}
                  className={cn(
                    "flex-1 rounded-[1px] transition-colors duration-200",
                    played[i] ? "bg-gold-400/80" : "bg-bone-100/14",
                  )}
                  style={{ height: `${h}%` }}
                />
              ))}
            </div>

            {/* playhead */}
            <span
              aria-hidden="true"
              className="pointer-events-none absolute -top-1 bottom-1 w-px bg-gold-300 shadow-[0_0_14px_2px_rgba(242,180,87,0.55)]"
              style={{ left: `${t * 100}%` }}
            >
              <span className="absolute -top-1 left-1/2 size-2.5 -translate-x-1/2 rotate-45 rounded-[2px] bg-gold-300" />
            </span>
          </div>

          <div className="mt-3 flex items-center justify-between font-mono text-[9.5px] tracking-[0.16em] text-smoke/70 uppercase">
            <span className="hidden sm:inline">Drag · hover · ← → to scrub</span>
            <span className="sm:hidden">Drag to scrub</span>
            <span className="text-gold-400/80 tabular-nums">
              FRAME {String(idx + 1).padStart(2, "0")}/{frames.length}
            </span>
          </div>
        </div>
      </div>

      {/* floating badge */}
      <div className="pointer-events-none absolute -bottom-7 -left-3 z-20 hidden sm:block lg:-left-10">
        <div className="panel flex items-center gap-3 rounded-full py-2.5 pr-5 pl-2.5 shadow-[0_24px_60px_-30px_rgba(0,0,0,1)] animate-float">
          <span className="grid size-8 place-items-center rounded-full bg-jade-500/15 text-jade-400">
            <Icon name="clock" size={16} />
          </span>
          <span className="leading-tight">
            <span className="block font-display text-sm font-bold text-bone-50">First cut in 72h</span>
            <span className="block font-mono text-[9px] tracking-[0.16em] text-smoke/80 uppercase">
              median, last 40 jobs
            </span>
          </span>
        </div>
      </div>
    </div>
  );
});

/* ------------------------------------------------------------------ */
/* Hero                                                                */
/* ------------------------------------------------------------------ */

/** Isolated pointer spotlight — keeps hero re-renders off the scrubber subtree. */
function Spotlight() {
  const ref = useRef<HTMLDivElement | null>(null);
  const [s, setS] = useState({ x: 50, y: 30, o: 0 });
  useEffect(() => {
    if (!window.matchMedia("(pointer: fine)").matches) return;
    let frame = 0;
    const on = (e: PointerEvent) => {
      if (frame) return;
      frame = requestAnimationFrame(() => {
        frame = 0;
        const el = ref.current;
        if (!el) return;
        const r = el.getBoundingClientRect();
        const x = ((e.clientX - r.left) / r.width) * 100;
        const y = ((e.clientY - r.top) / r.height) * 100;
        const inside = x > -15 && x < 115 && y > -20 && y < 120;
        setS({ x, y, o: inside ? 1 : 0 });
      });
    };
    window.addEventListener("pointermove", on, { passive: true });
    return () => {
      window.removeEventListener("pointermove", on);
      if (frame) cancelAnimationFrame(frame);
    };
  }, []);
  return (
    <div
      ref={ref}
      aria-hidden="true"
      className="absolute inset-0 transition-opacity duration-700"
      style={{
        opacity: s.o,
        background: `radial-gradient(360px circle at ${s.x}% ${s.y}%, rgba(242,180,87,0.1), transparent 70%)`,
      }}
    />
  );
}

export function Hero() {
  return (
    <section
      id="hero"
      className="relative isolate overflow-hidden pt-28 pb-16 sm:pt-32 lg:pt-40 lg:pb-24"
    >
      {/* ambient */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute inset-0 bg-[radial-gradient(90%_60%_at_18%_0%,rgba(242,180,87,0.14),transparent_60%),radial-gradient(70%_55%_at_92%_18%,rgba(226,96,63,0.13),transparent_62%),radial-gradient(60%_50%_at_70%_100%,rgba(79,184,160,0.11),transparent_60%)]" />
        <div
          className="absolute inset-0 opacity-[0.16] [background-image:linear-gradient(to_right,rgba(247,243,236,0.5)_1px,transparent_1px),linear-gradient(to_bottom,rgba(247,243,236,0.5)_1px,transparent_1px)] [background-size:88px_88px] [mask-image:radial-gradient(80%_60%_at_50%_30%,#000,transparent)]"
        />
        <div
          className="absolute top-[-20%] left-[-10%] h-[70vh] w-[45vw] rotate-[8deg] bg-gradient-to-r from-transparent via-gold-400/12 to-transparent blur-2xl animate-sweep"
        />
        <Spotlight />
        {/* floating clip chips */}
        {[
          { l: "12%", t: "22%", w: 62, c: "bg-gold-400", d: "0s" },
          { l: "8%", t: "64%", w: 40, c: "bg-jade-500", d: "-4s" },
          { l: "48%", t: "12%", w: 34, c: "bg-ember-500", d: "-8s" },
        ].map((c) => (
          <span
            key={c.l}
            className={cn(
              "absolute hidden h-1.5 rounded-full opacity-45 xl:block animate-float-slow",
              c.c,
            )}
            style={{ left: c.l, top: c.t, width: c.w, animationDelay: c.d }}
          />
        ))}
      </div>

      <div className="mx-auto w-full max-w-[1400px] px-4 sm:px-6 lg:px-10">
        <div className="grid items-center gap-14 lg:grid-cols-12 lg:gap-10">
          {/* copy */}
          <div className="lg:col-span-6 xl:col-span-6">
            <Reveal>
              <Eyebrow>
                Reel 2026 · {BRAND.base} → worldwide · now booking
              </Eyebrow>
            </Reveal>

            <h1 className="mt-6 font-display text-[clamp(2.7rem,7.6vw,5.1rem)] leading-[0.9] tracking-[-0.045em] text-bone-50">
              <MaskLines
                lines={[
                  "Forty hours",
                  <>
                    of footage <span className="text-smoke">in.</span>
                  </>,
                  <>
                    One cut nobody{" "}
                    <span className="relative whitespace-nowrap text-gold-400">
                      skips
                      <svg
                        viewBox="0 0 120 12"
                        className="absolute -bottom-1 left-0 h-2.5 w-full text-gold-500/70"
                        preserveAspectRatio="none"
                        aria-hidden="true"
                      >
                        <path
                          d="M2 8.5C22 3.5 58 2.5 118 6"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2.5"
                          strokeLinecap="round"
                        />
                      </svg>
                    </span>
                    .
                  </>,
                ]}
                delay={80}
              />
            </h1>

            <Reveal delay={340}>
              <p className="mt-8 max-w-xl text-[1.02rem] leading-[1.75] text-smoke sm:text-[1.1rem]">
                I'm {BRAND.name} — picture editor and colorist, eleven years in the chair. I take
                the rushes your shoot produced, find the film hiding inside them, and hand back a
                cut that still lands on the last frame. Brand films, documentaries, music videos.
              </p>
            </Reveal>

            <Reveal delay={440}>
              <div className="mt-9 flex flex-wrap items-center gap-3">
                <Button onClick={() => scrollToId("book")} size="lg" icon="arrowRight">
                  Book a fit call
                </Button>
                <Button
                  onClick={() => scrollToId("work")}
                  variant="ghost"
                  size="lg"
                  className="group"
                >
                  <span className="relative z-10 grid size-6 place-items-center rounded-full bg-bone-100/10 text-gold-300 transition-transform duration-500 group-hover:scale-110">
                    <Icon name="play" size={11} />
                  </span>
                  <span className="relative z-10">See the work</span>
                </Button>
              </div>
            </Reveal>

            <Reveal delay={540}>
              <dl className="mt-12 grid max-w-lg grid-cols-2 gap-px overflow-hidden rounded-[14px] border border-bone-100/10 bg-bone-100/10 sm:grid-cols-4">
                {STATS.map((s) => (
                  <div key={s.label} className="bg-ink-950/85 px-4 py-4 backdrop-blur-sm">
                    <dt className="font-mono text-[9.5px] tracking-[0.16em] text-smoke/70 uppercase">
                      {s.label}
                    </dt>
                    <dd className="mt-2 font-display text-xl font-bold text-bone-50 tabular-nums">
                      {s.decimals ? s.value.toFixed(s.decimals) : s.value}
                      {s.suffix}
                    </dd>
                  </div>
                ))}
              </dl>
            </Reveal>
          </div>

          {/* viewer */}
          <div className="lg:col-span-6 xl:col-span-6">
            <Reveal variant="scale" delay={200}>
              <ScrubViewer />
            </Reveal>
          </div>
        </div>

        {/* ticker */}
        <Reveal delay={200}>
          <div className="mt-20 flex flex-wrap items-center justify-between gap-4 border-t border-bone-100/10 pt-6 lg:mt-24">
            <p className="font-mono text-[10.5px] tracking-[0.2em] text-smoke/70 uppercase">
              Cut in Lisbon · delivered worldwide · {new Date().getFullYear()}
            </p>
            <button
              onClick={() => scrollToId("proof")}
              className="group inline-flex items-center gap-3 font-mono text-[10.5px] tracking-[0.2em] text-smoke/80 uppercase transition-colors hover:text-gold-300"
            >
              Scroll
              <span className="relative grid size-7 place-items-center rounded-full border border-bone-100/15 transition-colors group-hover:border-gold-400/60">
                <span className="absolute h-2 w-px bg-gold-400 animate-[float_2.4s_ease-in-out_infinite]" />
                <Icon name="chevron" size={13} className="translate-y-0.5" />
              </span>
            </button>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

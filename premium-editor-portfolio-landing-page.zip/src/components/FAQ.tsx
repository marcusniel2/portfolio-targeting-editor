import { useState } from "react";
import { BRAND, FAQS } from "@/lib/data";
import { scrollToId } from "@/lib/hooks";
import { cn } from "@/utils/cn";
import { Icon } from "./Icon";
import { Reveal, SectionHeading, Timecode } from "./ui";

export function FAQ() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section id="faq" className="relative overflow-hidden bg-ink-900 py-20 sm:py-28">
      <div aria-hidden="true" className="pointer-events-none absolute inset-0">
        <div className="absolute inset-0 bg-[radial-gradient(50%_45%_at_10%_0%,rgba(242,180,87,0.09),transparent_60%)]" />
      </div>

      <div className="relative mx-auto w-full max-w-[1400px] px-4 sm:px-6 lg:px-10">
        <div className="grid gap-12 lg:grid-cols-12 lg:gap-14">
          <div className="lg:col-span-4">
            <div className="lg:sticky lg:top-28">
              <SectionHeading
                eyebrow="Questions, answered plainly"
                title={[
                  <>The things</>,
                  <>
                    producers ask <span className="text-gold-400">first.</span>
                  </>,
                ]}
                lead="Eight answers to the questions that come up on every fit call. If yours isn't here, that's what the call is for."
              />

              <Reveal delay={140}>
                <div className="panel mt-9 rounded-[16px] p-6">
                  <div className="flex items-center gap-3">
                    <span className="grid size-11 place-items-center rounded-full bg-gold-400/12 text-gold-400">
                      <Icon name="mail" size={19} />
                    </span>
                    <div className="leading-tight">
                      <p className="font-display text-base font-bold text-bone-50">
                        Still deciding?
                      </p>
                      <Timecode className="mt-1 block text-smoke/70">
                        Reply within 4 business hours
                      </Timecode>
                    </div>
                  </div>
                  <p className="mt-4 text-[13.5px] leading-relaxed text-smoke">
                    Book a 20-minute fit call. No deck, no pitch theatre — you describe the footage
                    and I'll tell you honestly whether it's a film yet, and what it would cost to
                    get there.
                  </p>
                  <div className="mt-5 flex flex-col gap-2.5">
                    <button
                      onClick={() => scrollToId("book")}
                      className="btn-sheen group inline-flex items-center justify-center gap-2 rounded-full bg-gold-400 px-5 py-3 text-sm font-semibold text-ink-950 transition-all duration-300 hover:-translate-y-0.5 hover:bg-gold-300"
                    >
                      <span className="relative z-10">Book the fit call</span>
                      <span className="relative z-10 transition-transform duration-300 group-hover:translate-x-1">
                        <Icon name="arrowRight" size={15} strokeWidth={2} />
                      </span>
                    </button>
                    <a
                      href={`mailto:${BRAND.email}?subject=Fit%20call%20—%20post%20question`}
                      className="inline-flex items-center justify-center gap-2 rounded-full border border-bone-100/15 px-5 py-3 text-sm text-bone-100 transition-colors hover:border-gold-400/50 hover:text-gold-300"
                    >
                      <Icon name="mail" size={15} />
                      {BRAND.email}
                    </a>
                  </div>
                </div>
              </Reveal>
            </div>
          </div>

          <div className="lg:col-span-8">
            <div className="border-t border-bone-100/10">
              {FAQS.map((f, i) => {
                const isOpen = open === i;
                return (
                  <Reveal key={f.q} delay={i * 45}>
                    <div
                      className={cn(
                        "border-b border-bone-100/10 transition-colors duration-[400ms]",
                        isOpen ? "bg-bone-50/[0.035]" : "hover:bg-bone-50/[0.02]",
                      )}
                    >
                      <h3>
                        <button
                          onClick={() => setOpen(isOpen ? null : i)}
                          aria-expanded={isOpen}
                          aria-controls={`faq-${i}`}
                          className="flex w-full cursor-pointer items-start gap-4 px-3 py-6 text-left sm:gap-6 sm:px-5"
                        >
                          <Timecode
                            className={cn(
                              "mt-1.5 shrink-0 transition-colors duration-300",
                              isOpen ? "text-gold-400" : "text-smoke/50",
                            )}
                          >
                            {String(i + 1).padStart(2, "0")}
                          </Timecode>
                          <span
                            className={cn(
                              "flex-1 font-display text-[clamp(1.1rem,2.3vw,1.45rem)] leading-snug font-bold tracking-[-0.02em] transition-colors duration-300",
                              isOpen ? "text-bone-50" : "text-bone-100/85 hover:text-bone-50",
                            )}
                          >
                            {f.q}
                          </span>
                          <span
                            className={cn(
                              "mt-0.5 grid size-8 shrink-0 place-items-center rounded-full border transition-all duration-500",
                              isOpen
                                ? "rotate-180 border-gold-400/70 bg-gold-400/12 text-gold-300"
                                : "border-bone-100/15 text-smoke",
                            )}
                          >
                            <Icon name="chevron" size={15} strokeWidth={1.8} />
                          </span>
                        </button>
                      </h3>
                      <div
                        id={`faq-${i}`}
                        role="region"
                        className={cn(
                          "grid transition-[grid-template-rows,opacity] duration-500 ease-[cubic-bezier(0.16,1,0.3,1)]",
                          isOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0",
                        )}
                      >
                        <div className="overflow-hidden">
                          <p className="max-w-2xl px-3 pb-7 text-[14.5px] leading-[1.75] text-smoke sm:px-5 sm:pl-[3.9rem]">
                            {f.a}
                          </p>
                        </div>
                      </div>
                    </div>
                  </Reveal>
                );
              })}
            </div>

            <Reveal delay={80}>
              <div className="mt-8 flex flex-wrap items-center gap-x-6 gap-y-3 rounded-[14px] border border-bone-100/10 bg-ink-950/50 px-5 py-4">
                <Timecode className="text-jade-400">ALSO WORTH KNOWING</Timecode>
                {[
                  "Contracts in plain English",
                  "NDA on request, same day",
                  "Works with your in-house team",
                ].map((x) => (
                  <span key={x} className="inline-flex items-center gap-2 text-[13px] text-smoke">
                    <span className="size-1 rotate-45 bg-jade-500/70" />
                    {x}
                  </span>
                ))}
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}

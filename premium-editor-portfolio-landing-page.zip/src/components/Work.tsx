import { useCallback, useEffect, useRef, useState } from "react";
import { CATEGORIES, PROJECTS, type Project } from "@/lib/data";
import { scrollToId } from "@/lib/hooks";
import { cn } from "@/utils/cn";
import { Icon } from "./Icon";
import { Reveal, SectionHeading, Timecode } from "./ui";

function Meta({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="font-mono text-[9.5px] tracking-[0.18em] text-smoke/60 uppercase">{label}</dt>
      <dd className="mt-1.5 text-sm text-bone-100">{value}</dd>
    </div>
  );
}

export function Work() {
  const [filter, setFilter] = useState<(typeof CATEGORIES)[number]>("All");
  const [active, setActive] = useState<number | null>(null);
  const closeRef = useRef<HTMLButtonElement | null>(null);
  const lastFocus = useRef<HTMLElement | null>(null);

  const list = PROJECTS.filter((p) => filter === "All" || p.category === filter);

  /* re-balance the grid so a filtered view never looks half-empty */
  const spanFor = (p: Project) => {
    if (filter === "All") return p.span;
    if (list.length === 1) return "lg:col-span-8 lg:col-start-3";
    if (list.length === 2) return "lg:col-span-6";
    return "lg:col-span-4";
  };
  const aspectFor = (p: Project) =>
    filter !== "All" && list.length <= 2 ? `${p.aspect} lg:aspect-[16/10]` : p.aspect;
  const counts = CATEGORIES.map(
    (c) => (c === "All" ? PROJECTS.length : PROJECTS.filter((p) => p.category === c).length),
  );

  const step = useCallback(
    (dir: 1 | -1) => {
      setActive((cur) => {
        if (cur === null) return cur;
        return (cur + dir + list.length) % list.length;
      });
    },
    [list.length],
  );

  useEffect(() => {
    if (active === null) return;
    lastFocus.current = document.activeElement as HTMLElement;
    document.body.style.overflow = "hidden";
    closeRef.current?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setActive(null);
      if (e.key === "ArrowRight") step(1);
      if (e.key === "ArrowLeft") step(-1);
    };
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
      lastFocus.current?.focus?.();
    };
  }, [active, step]);

  const project: Project | undefined = active !== null ? list[active] : undefined;

  return (
    <section id="work" className="relative overflow-hidden bg-ink-950 py-20 sm:py-28">
      <div aria-hidden="true" className="pointer-events-none absolute inset-0">
        <div className="absolute inset-0 bg-[radial-gradient(65%_45%_at_75%_5%,rgba(226,96,63,0.1),transparent_65%),radial-gradient(50%_40%_at_10%_60%,rgba(79,184,160,0.08),transparent_60%)]" />
      </div>

      <div className="relative mx-auto w-full max-w-[1400px] px-4 sm:px-6 lg:px-10">
        <SectionHeading
          eyebrow="Selected work · 2024 – 2026"
          title={[
            <>Every frame had</>,
            <>
              to <span className="text-gold-400">earn</span> its place.
            </>,
          ]}
          lead="Seven films from the last two years — brand campaigns that moved a number, documentaries that played festivals, and music videos that people watched twice. Open any card for the story behind the cut."
          aside={
            <div className="flex items-center gap-4 rounded-full border border-bone-100/12 bg-ink-900/60 px-5 py-3 backdrop-blur">
              <span className="grid size-9 place-items-center rounded-full bg-gold-400/12 text-gold-400">
                <Icon name="film" size={17} />
              </span>
              <span className="leading-tight">
                <span className="block font-display text-sm font-bold text-bone-50">
                  Full reel on request
                </span>
                <span className="block font-mono text-[9.5px] tracking-[0.16em] text-smoke/70 uppercase">
                  NDA work · 40+ unreleased cuts
                </span>
              </span>
            </div>
          }
        />

        {/* filters */}
        <Reveal delay={80}>
          <div className="mt-12 flex flex-wrap items-center gap-2 border-y border-bone-100/10 py-4">
            <Timecode className="mr-2 hidden text-smoke/60 sm:inline">FILTER</Timecode>
            {CATEGORIES.map((c, i) => {
              const on = filter === c;
              return (
                <button
                  key={c}
                  onClick={() => setFilter(c)}
                  aria-pressed={on}
                  className={cn(
                    "group inline-flex items-center gap-2 rounded-full border px-4 py-2 text-[13px] font-medium transition-all duration-300",
                    on
                      ? "border-gold-400 bg-gold-400 text-ink-950 shadow-[0_10px_30px_-14px_rgba(242,180,87,0.9)]"
                      : "border-bone-100/14 text-smoke hover:-translate-y-0.5 hover:border-gold-400/50 hover:text-bone-50",
                  )}
                >
                  {c}
                  <span
                    className={cn(
                      "font-mono text-[9.5px] tabular-nums",
                      on ? "text-ink-950/60" : "text-smoke/50",
                    )}
                  >
                    {String(counts[i]).padStart(2, "0")}
                  </span>
                </button>
              );
            })}
            <span className="ml-auto hidden font-mono text-[10px] tracking-[0.16em] text-smoke/50 uppercase md:inline">
              {list.length} showing · click for case study
            </span>
          </div>
        </Reveal>

        {/* grid */}
        <div className="mt-6 grid gap-4 sm:gap-5 lg:grid-cols-12">
          {list.map((p, i) => (
            <Reveal
              key={`${filter}-${p.id}`}
              variant="scale"
              delay={(i % 3) * 90}
              className={cn("group", spanFor(p))}
            >
              <article className="relative h-full w-full overflow-hidden rounded-[14px] border border-bone-100/10 bg-ink-900 transition-all duration-500 hover:-translate-y-1.5 hover:border-gold-400/40 hover:shadow-[0_40px_80px_-40px_rgba(0,0,0,1)]">
                <div className={cn("relative w-full overflow-hidden", aspectFor(p))}>
                  <img
                    src={p.image}
                    alt={`${p.title} — ${p.category} for ${p.client}`}
                    loading="lazy"
                    decoding="async"
                    className="absolute inset-0 size-full object-cover transition-transform duration-[1.4s] ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:scale-[1.09]"
                  />
                  <span className="absolute inset-0 bg-gradient-to-t from-ink-950 via-ink-950/25 to-transparent opacity-90" />

                  {/* category + year */}
                  <div className="absolute inset-x-0 top-0 flex items-start justify-between gap-3 p-3.5 sm:p-4">
                    <span className="rounded-full border border-bone-100/15 bg-ink-950/60 px-2.5 py-1 font-mono text-[9.5px] tracking-[0.18em] text-bone-100/85 uppercase backdrop-blur-md">
                      {p.category}
                    </span>
                    <span className="rounded-full border border-bone-100/15 bg-ink-950/60 px-2.5 py-1 font-mono text-[9.5px] tracking-[0.14em] text-smoke backdrop-blur-md">
                      {p.year}
                    </span>
                  </div>

                  {/* play affordance */}
                  <span className="absolute top-1/2 left-1/2 grid size-14 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full border border-gold-400/50 bg-ink-950/45 text-gold-300 opacity-0 backdrop-blur-md transition-all duration-500 group-hover:scale-110 group-hover:opacity-100">
                    <Icon name="play" size={17} />
                  </span>

                  {/* copy */}
                  <div className="absolute inset-x-0 bottom-0 p-4 sm:p-5">
                    <div className="flex items-end justify-between gap-4">
                      <div className="min-w-0">
                        <h3 className="truncate font-display text-[clamp(1.25rem,2.4vw,1.75rem)] leading-none font-bold tracking-tight text-bone-50">
                          {p.title}
                        </h3>
                        <p className="mt-2 font-mono text-[10px] tracking-[0.16em] text-smoke/85 uppercase">
                          {p.client} · {p.runtime} · {p.role}
                        </p>
                      </div>
                      <div className="shrink-0 text-right">
                        <p className="font-display text-lg leading-none font-bold text-gold-400">
                          {p.metric}
                        </p>
                        <p className="mt-1 font-mono text-[9px] tracking-[0.14em] text-smoke/70 uppercase">
                          {p.metricLabel}
                        </p>
                      </div>
                    </div>
                    <div className="grid grid-rows-[0fr] transition-[grid-template-rows] duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:grid-rows-[1fr]">
                      <div className="overflow-hidden">
                        <p className="pt-3 text-[13px] leading-relaxed text-bone-200/85">
                          {p.blurb}
                        </p>
                        <span className="mt-3 inline-flex items-center gap-2 font-mono text-[10px] tracking-[0.18em] text-gold-300 uppercase">
                          Case study
                          <Icon name="arrowUpRight" size={13} />
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => setActive(i)}
                  aria-label={`Open case study: ${p.title} for ${p.client}`}
                  className="absolute inset-0 z-20 cursor-pointer"
                >
                  <span className="sr-only">Open case study</span>
                </button>
              </article>
            </Reveal>
          ))}
        </div>

        <Reveal delay={100}>
          <div className="panel mt-10 flex flex-col items-center justify-between gap-5 rounded-[16px] px-6 py-7 sm:flex-row sm:px-9">
            <div className="text-center sm:text-left">
              <p className="font-display text-xl font-bold text-bone-50 sm:text-2xl">
                Your film could be sitting in this grid next quarter.
              </p>
              <p className="mt-2 max-w-xl text-sm text-smoke">
                Two slots open for March. Send the footage, a brief and two references — you'll have
                a first cut in 72 hours.
              </p>
            </div>
            <button
              onClick={() => scrollToId("book")}
              className="btn-sheen group inline-flex shrink-0 items-center gap-2.5 rounded-full bg-gold-400 px-6 py-3.5 text-sm font-semibold text-ink-950 transition-all duration-300 hover:-translate-y-0.5 hover:bg-gold-300"
            >
              <span className="relative z-10">Claim a slot</span>
              <span className="relative z-10 transition-transform duration-300 group-hover:translate-x-1">
                <Icon name="arrowRight" size={16} strokeWidth={2} />
              </span>
            </button>
          </div>
        </Reveal>
      </div>

      {/* ---------------- case study modal ---------------- */}
      {project && (
        <div
          className="fixed inset-0 z-[70] flex items-end justify-center p-0 sm:items-center sm:p-6"
          role="dialog"
          aria-modal="true"
          aria-labelledby="case-title"
        >
          <div
            className="absolute inset-0 bg-ink-950/85 backdrop-blur-md"
            onClick={() => setActive(null)}
          />
          <div className="relative z-10 max-h-[92vh] w-full max-w-4xl overflow-y-auto rounded-t-[20px] border border-bone-100/12 bg-ink-900 shadow-[0_60px_140px_-40px_rgba(0,0,0,1)] sm:rounded-[18px]">
            <div className="relative aspect-[16/9] w-full overflow-hidden">
              <img
                src={project.image}
                alt={`${project.title} still`}
                className="size-full object-cover"
              />
              <span className="absolute inset-0 bg-gradient-to-t from-ink-900 via-ink-900/25 to-transparent" />
              <button
                ref={closeRef}
                onClick={() => setActive(null)}
                className="absolute top-4 right-4 grid size-10 place-items-center rounded-full border border-bone-100/20 bg-ink-950/70 text-bone-100 backdrop-blur-md transition-colors hover:border-ember-500/60 hover:text-ember-400"
                aria-label="Close case study"
              >
                <Icon name="close" size={17} />
              </button>
              <div className="absolute bottom-4 left-5 sm:bottom-6 sm:left-8">
                <Timecode className="text-gold-400">
                  {project.category} · {project.year}
                </Timecode>
                <h3
                  id="case-title"
                  className="mt-2 font-display text-[clamp(1.8rem,4.6vw,2.8rem)] leading-none font-bold text-bone-50"
                >
                  {project.title}
                </h3>
              </div>
            </div>

            <div className="p-5 sm:p-8">
              <p className="max-w-2xl text-[1.02rem] leading-relaxed text-bone-200/90">
                {project.blurb}
              </p>
              <dl className="mt-7 grid grid-cols-2 gap-6 border-t border-bone-100/10 pt-6 sm:grid-cols-4">
                <Meta label="Client" value={project.client} />
                <Meta label="Runtime" value={project.runtime} />
                <Meta label="My role" value={project.role} />
                <Meta label="Result" value={`${project.metric} ${project.metricLabel}`} />
              </dl>
              <div className="mt-8 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => step(-1)}
                    className="inline-flex items-center gap-2 rounded-full border border-bone-100/15 px-4 py-2.5 text-[13px] text-bone-100 transition-colors hover:border-gold-400/60 hover:text-gold-300"
                  >
                    <Icon name="arrowRight" size={14} className="rotate-180" />
                    Previous
                  </button>
                  <button
                    onClick={() => step(1)}
                    className="inline-flex items-center gap-2 rounded-full border border-bone-100/15 px-4 py-2.5 text-[13px] text-bone-100 transition-colors hover:border-gold-400/60 hover:text-gold-300"
                  >
                    Next project
                    <Icon name="arrowRight" size={14} />
                  </button>
                  <Timecode className="ml-2 text-smoke/50">
                    {String((active ?? 0) + 1).padStart(2, "0")} / {String(list.length).padStart(2, "0")}
                  </Timecode>
                </div>
                <button
                  onClick={() => {
                    setActive(null);
                    window.setTimeout(() => scrollToId("book"), 240);
                  }}
                  className="btn-sheen group inline-flex items-center gap-2 rounded-full bg-gold-400 px-5 py-2.5 text-[13px] font-semibold text-ink-950 transition-all duration-300 hover:-translate-y-0.5 hover:bg-gold-300"
                >
                  <span className="relative z-10">Start something like this</span>
                  <span className="relative z-10 transition-transform duration-300 group-hover:translate-x-1">
                    <Icon name="arrowRight" size={14} strokeWidth={2} />
                  </span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}

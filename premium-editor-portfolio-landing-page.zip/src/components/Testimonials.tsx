import { useEffect, useState } from "react";
import { TESTIMONIALS } from "@/lib/data";
import { useReducedMotion } from "@/lib/hooks";
import { cn } from "@/utils/cn";
import { Icon } from "./Icon";
import { Marquee, Reveal, SectionHeading, Timecode } from "./ui";

const AUTOPLAY_MS = 7200;

export function Testimonials() {
  const [i, setI] = useState(0);
  const [paused, setPaused] = useState(false);
  const reduced = useReducedMotion();
  const t = TESTIMONIALS[i];

  useEffect(() => {
    if (paused || reduced) return;
    const id = window.setTimeout(() => setI((p) => (p + 1) % TESTIMONIALS.length), AUTOPLAY_MS);
    return () => window.clearTimeout(id);
  }, [i, paused, reduced]);

  const go = (dir: 1 | -1) =>
    setI((p) => (p + dir + TESTIMONIALS.length) % TESTIMONIALS.length);

  return (
    <section id="voices" className="relative overflow-hidden bg-ink-950 py-20 sm:py-28">
      <div aria-hidden="true" className="pointer-events-none absolute inset-0">
        <div className="absolute inset-0 bg-[radial-gradient(60%_50%_at_20%_0%,rgba(242,180,87,0.11),transparent_62%),radial-gradient(45%_40%_at_90%_70%,rgba(79,184,160,0.09),transparent_60%)]" />
        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-bone-100/14 to-transparent" />
      </div>

      <div className="relative mx-auto w-full max-w-[1400px] px-4 sm:px-6 lg:px-10">
        <SectionHeading
          eyebrow="Client voices · 38 reviews"
          title={[
            <>The notes I get</>,
            <>
              after the <span className="text-gold-400">master</span> lands.
            </>,
          ]}
          lead="No testimonials written by a marketing intern. These are the messages that arrived after delivery — from the people who signed the brief and watched the numbers."
          aside={
            <div className="flex items-center gap-4 rounded-[14px] border border-bone-100/12 bg-ink-900/70 px-5 py-4 backdrop-blur">
              <div className="flex gap-1 text-gold-400">
                {Array.from({ length: 5 }).map((_, s) => (
                  <Icon key={s} name="star" size={15} />
                ))}
              </div>
              <div className="leading-tight">
                <p className="font-display text-xl font-bold text-bone-50">5.0</p>
                <p className="font-mono text-[9.5px] tracking-[0.16em] text-smoke/70 uppercase">
                  avg · 38 client reviews
                </p>
              </div>
            </div>
          }
        />

        {/* featured quote */}
        <Reveal variant="scale" delay={80}>
          <div
            className="panel relative mt-12 overflow-hidden rounded-[18px]"
            onMouseEnter={() => setPaused(true)}
            onMouseLeave={() => setPaused(false)}
            onFocusCapture={() => setPaused(true)}
            onBlurCapture={() => setPaused(false)}
          >
            <span
              aria-hidden="true"
              className="pointer-events-none absolute -top-16 -left-6 font-display text-[13rem] leading-none font-bold text-gold-400/8 select-none sm:text-[18rem]"
            >
              &ldquo;
            </span>

            <div className="relative grid gap-8 p-6 sm:p-9 lg:grid-cols-12 lg:gap-10">
              <div className="lg:col-span-4">
                <div className="relative mx-auto w-40 overflow-hidden rounded-full border border-gold-400/30 sm:mx-0 sm:w-44">
                  <img
                    src={t.avatar}
                    alt={t.name}
                    loading="lazy"
                    className="size-full aspect-square object-cover"
                    style={{ filter: "saturate(0.92) contrast(1.05)" }}
                  />
                  <span className="absolute inset-0 rounded-full bg-gradient-to-t from-ink-950/45 to-transparent" />
                </div>
                <div className="mt-5 text-center sm:text-left">
                  <p className="font-display text-xl leading-tight font-bold text-bone-50">
                    {t.name}
                  </p>
                  <p className="mt-1 text-[13.5px] text-smoke">{t.role}</p>
                  <p className="font-mono text-[10px] tracking-[0.16em] text-gold-400 uppercase">
                    {t.company}
                  </p>
                  <p className="mt-4 inline-flex items-center gap-2 rounded-full border border-bone-100/12 bg-ink-950/50 px-3 py-1.5 font-mono text-[9.5px] tracking-[0.14em] text-smoke/80 uppercase">
                    <Icon name="film" size={12} />
                    {t.project}
                  </p>
                </div>
              </div>

              <div className="lg:col-span-8">
                <blockquote
                  key={t.name}
                  className="font-display text-[clamp(1.35rem,3vw,2.15rem)] leading-[1.18] font-medium tracking-[-0.028em] text-bone-50"
                  style={{
                    animation: reduced ? undefined : "quote-in .7s cubic-bezier(0.16,1,0.3,1) both",
                  }}
                >
                  {t.quote}
                </blockquote>

                <div className="mt-8 flex flex-wrap items-center justify-between gap-5 border-t border-bone-100/10 pt-6">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => go(-1)}
                      aria-label="Previous testimonial"
                      className="grid size-10 place-items-center rounded-full border border-bone-100/15 text-bone-100 transition-all duration-300 hover:-translate-x-0.5 hover:border-gold-400/60 hover:text-gold-300"
                    >
                      <Icon name="arrowRight" size={15} className="rotate-180" />
                    </button>
                    <button
                      onClick={() => go(1)}
                      aria-label="Next testimonial"
                      className="grid size-10 place-items-center rounded-full border border-bone-100/15 text-bone-100 transition-all duration-300 hover:translate-x-0.5 hover:border-gold-400/60 hover:text-gold-300"
                    >
                      <Icon name="arrowRight" size={15} />
                    </button>
                    <Timecode className="ml-3 text-smoke/55">
                      {String(i + 1).padStart(2, "0")} / {String(TESTIMONIALS.length).padStart(2, "0")}
                    </Timecode>
                  </div>

                  <div className="flex items-center gap-1.5">
                    {TESTIMONIALS.map((x, n) => (
                      <button
                        key={x.name}
                        onClick={() => setI(n)}
                        aria-label={`Show testimonial from ${x.name}`}
                        aria-current={n === i}
                        className={cn(
                          "h-1.5 rounded-full transition-all duration-500",
                          n === i
                            ? "w-9 bg-gold-400"
                            : "w-3 bg-bone-100/20 hover:bg-bone-100/45",
                        )}
                      />
                    ))}
                  </div>
                </div>

                {/* autoplay progress */}
                <div className="mt-5 h-px w-full overflow-hidden bg-bone-100/10">
                  <span
                    key={`${i}-${reduced}`}
                    className="block h-full origin-left bg-gradient-to-r from-gold-400 to-ember-500"
                    style={{
                      animation: reduced ? "none" : `tl ${AUTOPLAY_MS}ms linear forwards`,
                      animationPlayState: paused ? "paused" : "running",
                      transform: reduced ? "scaleX(1)" : undefined,
                    }}
                  />
                </div>
              </div>
            </div>
          </div>
        </Reveal>

        {/* marquee of cards */}
        <div className="mt-10">
          <Marquee speed={78}>
            {TESTIMONIALS.map((x) => (
              <article
                key={x.name + "m"}
                className="mx-2.5 w-[330px] shrink-0 rounded-[14px] border border-bone-100/10 bg-ink-900/70 p-5 transition-colors duration-300 hover:border-gold-400/35 sm:w-[380px]"
              >
                <div className="flex items-center gap-3">
                  <img
                    src={x.avatar}
                    alt=""
                    loading="lazy"
                    className="size-9 rounded-full object-cover"
                  />
                  <div className="min-w-0">
                    <p className="truncate text-[13.5px] font-semibold text-bone-100">{x.name}</p>
                    <p className="truncate font-mono text-[9px] tracking-[0.14em] text-smoke/65 uppercase">
                      {x.company}
                    </p>
                  </div>
                  <div className="ml-auto flex gap-0.5 text-gold-400">
                    {Array.from({ length: x.rating }).map((_, s) => (
                      <Icon key={s} name="star" size={11} />
                    ))}
                  </div>
                </div>
                <p className="mt-3.5 line-clamp-4 text-[13.5px] leading-relaxed text-smoke">
                  {x.quote}
                </p>
              </article>
            ))}
          </Marquee>
        </div>
      </div>

      <style>{`
        @keyframes quote-in { from { opacity: 0; transform: translateY(14px); filter: blur(5px); } to { opacity: 1; transform: none; filter: blur(0); } }
        @keyframes tl { from { transform: scaleX(0); } to { transform: scaleX(1); } }
      `}</style>
    </section>
  );
}

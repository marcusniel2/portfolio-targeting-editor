import { BRAND, FOOTER_LINKS } from "@/lib/data";
import { scrollToId, useLocalTime } from "@/lib/hooks";
import { Icon } from "./Icon";
import { Marquee, Timecode } from "./ui";

const STRIP = [
  "Available for March",
  "First cut in 72h",
  "Flat project rates",
  "Frame.io review",
  "Lisbon → worldwide",
  "Now booking",
];

export function Footer() {
  const time = useLocalTime(BRAND.tz);

  return (
    <footer className="relative overflow-hidden border-t border-bone-100/10 bg-ink-950">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 bg-[radial-gradient(70%_60%_at_50%_120%,rgba(242,180,87,0.12),transparent_65%)]"
      />

      {/* availability strip */}
      <div className="relative border-b border-bone-100/10 bg-ink-900/70 py-3">
        <Marquee speed={44}>
          {STRIP.map((s) => (
            <span
              key={s}
              className="flex items-center gap-5 px-6 font-mono text-[10.5px] tracking-[0.24em] text-smoke/70 uppercase"
            >
              <span className="size-1 rounded-full bg-gold-400/70" />
              {s}
            </span>
          ))}
        </Marquee>
      </div>

      <div className="relative mx-auto w-full max-w-[1400px] px-4 pt-16 sm:px-6 lg:px-10">
        <div className="grid gap-12 lg:grid-cols-12 lg:gap-10">
          {/* identity */}
          <div className="lg:col-span-4">
            <div className="flex items-center gap-3">
              <span className="text-gold-400/40">
                <svg width="38" height="38" viewBox="0 0 40 40" aria-hidden="true">
                  <rect width="40" height="40" rx="9" fill="#181514" />
                  <path d="M10 13.5h5.6l3.8 8.2 3.8-8.2H28.8l-6.7 13H16.7z" fill="#F2B457" />
                  <circle cx="28.4" cy="28" r="3.1" fill="#4FB8A0" />
                </svg>
              </span>
              <div className="leading-tight">
                <p className="font-display text-lg font-bold text-bone-50">{BRAND.name}</p>
                <p className="font-mono text-[9.5px] tracking-[0.2em] text-smoke/70 uppercase">
                  {BRAND.role}
                </p>
              </div>
            </div>
            <p className="mt-6 max-w-sm text-[14px] leading-relaxed text-smoke">
              Freelance picture editor and colorist working with brands, bands and documentary
              teams since {BRAND.since}. One chair, one calibrated suite, no handoff — the person
              you brief is the person who cuts.
            </p>
            <div className="mt-6 flex flex-col gap-2.5">
              <a
                href={`mailto:${BRAND.email}`}
                className="group inline-flex w-fit items-center gap-2.5 text-[14px] text-bone-100 transition-colors hover:text-gold-300"
              >
                <Icon name="mail" size={15} className="text-smoke/70 transition-colors group-hover:text-gold-400" />
                {BRAND.email}
              </a>
              <a
                href={`tel:${BRAND.phone.replace(/\s/g, "")}`}
                className="group inline-flex w-fit items-center gap-2.5 text-[14px] text-bone-100 transition-colors hover:text-gold-300"
              >
                <Icon name="phone" size={15} className="text-smoke/70 transition-colors group-hover:text-gold-400" />
                {BRAND.phone}
              </a>
              <span className="inline-flex w-fit items-center gap-2.5 text-[14px] text-smoke">
                <Icon name="pin" size={15} className="text-smoke/70" />
                {BRAND.base} ·{" "}
                <span className="font-mono text-[12px] text-bone-200 tabular-nums">{time}</span>
              </span>
            </div>
          </div>

          {/* links */}
          {Object.entries(FOOTER_LINKS).map(([group, links]) => (
            <nav key={group} aria-label={group} className="lg:col-span-2">
              <p className="font-mono text-[10px] tracking-[0.22em] text-gold-400/85 uppercase">
                {group}
              </p>
              <ul className="mt-5 space-y-2.5">
                {links.map((l) => (
                  <li key={l.label}>
                    <a
                      href={l.href}
                      onClick={(e) => {
                        if (l.href.startsWith("#")) {
                          e.preventDefault();
                          scrollToId(l.href.slice(1));
                        }
                      }}
                      className="underline-slide inline-flex items-baseline gap-2 text-[13.5px] text-smoke transition-colors duration-300 hover:text-bone-50"
                    >
                      {l.label}
                      {"note" in l && l.note && (
                        <span className="font-mono text-[9.5px] text-smoke/45">{l.note}</span>
                      )}
                    </a>
                  </li>
                ))}
              </ul>
            </nav>
          ))}

          <div className="lg:col-span-2">
            <p className="font-mono text-[10px] tracking-[0.22em] text-gold-400/85 uppercase">
              Next step
            </p>
            <div className="mt-5 rounded-[14px] border border-jade-500/22 bg-jade-500/[0.07] p-4">
              <span className="inline-flex items-center gap-2">
                <span className="relative flex size-1.5">
                  <span className="absolute inset-0 rounded-full bg-jade-400 animate-pulse-ring" />
                  <span className="relative size-1.5 rounded-full bg-jade-400" />
                </span>
                <Timecode className="text-jade-400">{BRAND.availability}</Timecode>
              </span>
              <button
                onClick={() => scrollToId("book")}
                className="btn-sheen group mt-4 inline-flex w-full items-center justify-center gap-2 rounded-full bg-gold-400 px-4 py-2.5 text-[13px] font-semibold text-ink-950 transition-all duration-300 hover:-translate-y-0.5 hover:bg-gold-300"
              >
                <span className="relative z-10">Book a slot</span>
                <span className="relative z-10 transition-transform duration-300 group-hover:translate-x-1">
                  <Icon name="arrowRight" size={14} strokeWidth={2} />
                </span>
              </button>
            </div>
          </div>
        </div>

        {/* giant wordmark */}
        <div className="mt-16 select-none">
          <p className="wordmark text-center font-display text-[clamp(2.35rem,13.2vw,11.5rem)] leading-[0.8] font-bold tracking-[-0.055em] whitespace-nowrap">
            JULES MERCIER
          </p>
        </div>

        {/* bottom bar */}
        <div className="mt-10 flex flex-col items-center justify-between gap-4 border-t border-bone-100/10 py-7 sm:flex-row">
          <p className="text-center font-mono text-[10px] tracking-[0.16em] text-smoke/55 uppercase sm:text-left">
            © {new Date().getFullYear()} {BRAND.name} · Cut in Lisbon · Delivered worldwide
          </p>
          <div className="flex items-center gap-5">
            <span className="hidden font-mono text-[10px] tracking-[0.14em] text-smoke/40 uppercase md:inline">
              Built between renders
            </span>
            <button
              onClick={() => {
                const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
                window.scrollTo({ top: 0, behavior: reduced ? "auto" : "smooth" });
              }}
              className="group inline-flex items-center gap-2 rounded-full border border-bone-100/15 px-4 py-2 text-[12px] text-bone-100 transition-all duration-300 hover:-translate-y-0.5 hover:border-gold-400/60 hover:text-gold-300"
            >
              Back to top
              <span className="transition-transform duration-300 group-hover:-translate-y-0.5">
                <Icon name="arrowRight" size={14} className="-rotate-90" />
              </span>
            </button>
          </div>
        </div>
      </div>

      <style>{`
        .wordmark {
          color: transparent;
          -webkit-text-stroke: 1px rgba(201,189,167,0.3);
          transition: color .9s cubic-bezier(0.16,1,0.3,1), -webkit-text-stroke-color .9s ease;
        }
        .wordmark:hover {
          color: rgba(242,180,87,0.92);
          -webkit-text-stroke-color: transparent;
        }
      `}</style>
    </footer>
  );
}

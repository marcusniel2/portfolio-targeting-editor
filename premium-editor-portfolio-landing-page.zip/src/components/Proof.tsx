import { CLIENTS, STATS } from "@/lib/data";
import { useCountUp, useInView } from "@/lib/hooks";
import { Marquee, Reveal, Timecode } from "./ui";

const CREDENTIALS = [
  "Sundance official selection",
  "Cannes shortlist · craft",
  "Vimeo Staff Pick ×6",
  "AICP nominee 2025",
  "Webby honoree",
  "D&AD wood pencil",
  "1.2B campaign views",
  "Broadcast QC: zero rejections",
];

function Stat({ s, i }: { s: (typeof STATS)[number]; i: number }) {
  const { ref, inView } = useInView<HTMLDivElement>({ threshold: 0.4 });
  const n = useCountUp(s.value, inView, 1500 + i * 120, s.decimals ?? 0);
  return (
    <div
      ref={ref}
      className="group relative px-5 py-8 sm:px-7 sm:py-10"
      style={{ transitionDelay: `${i * 80}ms` }}
    >
      <span className="absolute top-5 left-5 font-mono text-[9.5px] tracking-[0.18em] text-gold-500/70 sm:left-7">
        0{i + 1}
      </span>
      <p className="mt-5 font-display text-[clamp(2.1rem,4.6vw,3.1rem)] leading-none font-bold text-bone-50 tabular-nums">
        {s.decimals ? n.toFixed(s.decimals) : Math.round(n)}
        <span className="text-gold-400">{s.suffix}</span>
      </p>
      <p className="mt-3 text-sm font-medium text-bone-200">{s.label}</p>
      <p className="mt-1 font-mono text-[10px] tracking-[0.14em] text-smoke/65 uppercase">{s.sub}</p>
      <span className="absolute inset-x-5 bottom-0 h-px origin-left scale-x-0 bg-gradient-to-r from-gold-400 to-transparent transition-transform duration-700 group-hover:scale-x-100 sm:inset-x-7" />
    </div>
  );
}

export function Proof() {
  return (
    <section id="proof" className="relative border-y border-bone-100/10 bg-ink-900">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 bg-[radial-gradient(60%_100%_at_50%_0%,rgba(242,180,87,0.07),transparent_70%)]"
      />

      <div className="relative py-12 sm:py-14">
        <Reveal className="mx-auto w-full max-w-[1400px] px-4 sm:px-6 lg:px-10">
          <div className="flex flex-wrap items-center gap-x-5 gap-y-2">
            <Timecode className="text-gold-400">TRUSTED IN THE SUITE BY</Timecode>
            <span className="hidden h-px flex-1 bg-bone-100/10 sm:block" />
            <Timecode className="text-smoke/60">14 BRANDS · 6 AGENCIES · 3 BROADCASTERS</Timecode>
          </div>
        </Reveal>

        <div className="mt-8 space-y-4">
          <Marquee speed={54}>
            {CLIENTS.map((c) => (
              <span
                key={c}
                className="group flex items-center gap-8 px-8 font-display text-[1.35rem] font-bold tracking-tight whitespace-nowrap text-bone-200/45 transition-colors duration-300 hover:text-gold-300 sm:text-[1.6rem]"
              >
                {c}
                <span className="size-1 rounded-full bg-ember-500/50 transition-colors group-hover:bg-ember-400" />
              </span>
            ))}
          </Marquee>
          <Marquee speed={68} reverse>
            {CREDENTIALS.map((c) => (
              <span
                key={c}
                className="flex items-center gap-4 px-6 font-mono text-[11px] tracking-[0.18em] whitespace-nowrap text-smoke/55 uppercase transition-colors hover:text-jade-400"
              >
                <span className="size-1 rotate-45 bg-jade-500/60" />
                {c}
              </span>
            ))}
          </Marquee>
        </div>

        <div className="mx-auto mt-12 w-full max-w-[1400px] px-4 sm:px-6 lg:px-10">
          <Reveal variant="scale">
            <div className="grid grid-cols-2 gap-px overflow-hidden rounded-[16px] border border-bone-100/10 bg-bone-100/10 lg:grid-cols-4">
              {STATS.map((s, i) => (
                <div key={s.label} className="bg-ink-900">
                  <Stat s={s} i={i} />
                </div>
              ))}
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

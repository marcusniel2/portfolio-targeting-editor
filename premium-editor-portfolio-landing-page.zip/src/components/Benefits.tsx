import { BENEFITS, IMG, PROCESS } from "@/lib/data";
import { scrollToId, useInView } from "@/lib/hooks";
import { Icon } from "./Icon";
import { Marquee, Reveal, SectionHeading } from "./ui";

const MANIFESTO = ["CUT TIGHTER", "GRADE DEEPER", "MIX LOUDER", "DELIVER EARLY", "KEEP EVERY PROMISE"];

function Process() {
  const { ref, inView } = useInView<HTMLDivElement>({ threshold: 0.25 });
  return (
    <div ref={ref} className="mt-20">
      <div className="flex flex-wrap items-end justify-between gap-4 border-b border-ash/20 pb-5">
        <h3 className="font-display text-[clamp(1.5rem,3vw,2.1rem)] font-bold tracking-[-0.03em] text-ink-900">
          How a project actually runs
        </h3>
        <p className="font-mono text-[10px] tracking-[0.18em] text-ash uppercase">
          Brief → delivery · 10 working days typical
        </p>
      </div>

      <div className="relative mt-10">
        {/* connector */}
        <span
          aria-hidden="true"
          className="absolute top-[7px] left-0 hidden h-px bg-ash/20 lg:block lg:w-full"
        />
        <span
          aria-hidden="true"
          className="absolute top-[7px] left-0 hidden h-px origin-left bg-gradient-to-r from-gold-500 via-ember-500 to-jade-500 transition-transform duration-[1800ms] ease-[cubic-bezier(0.16,1,0.3,1)] lg:block lg:w-full"
          style={{ transform: `scaleX(${inView ? 1 : 0})` }}
        />

        <ol className="grid gap-8 sm:grid-cols-2 lg:grid-cols-6 lg:gap-5">
          {PROCESS.map((p, i) => (
            <li
              key={p.step}
              className="relative"
              style={{
                opacity: inView ? 1 : 0,
                transform: inView ? "none" : "translateY(18px)",
                transition: `opacity .7s ease ${i * 110}ms, transform .8s cubic-bezier(0.16,1,0.3,1) ${i * 110}ms`,
              }}
            >
              <span className="relative z-10 flex size-[15px] items-center justify-center rounded-full border-2 border-ash/30 bg-bone-100 transition-colors duration-500 lg:border-gold-500">
                <span className="size-[5px] rounded-full bg-ash/40 transition-colors duration-500 lg:bg-gold-600" />
              </span>
              <p className="mt-4 font-mono text-[10px] tracking-[0.18em] text-gold-600">{p.step}</p>
              <p className="mt-1.5 font-display text-lg leading-tight font-bold text-ink-900">
                {p.title}
              </p>
              <p className="mt-2 text-[13.5px] leading-relaxed text-ash">{p.detail}</p>
            </li>
          ))}
        </ol>
      </div>
    </div>
  );
}

export function Benefits() {
  return (
    <section id="why" className="relative overflow-hidden bg-bone-100 pb-20 sm:pb-28">
      {/* manifesto band — breaks the light-to-light rhythm */}
      <div className="relative z-10 border-b border-ash/20 bg-ink-950 py-5 sm:py-6">
        <span
          aria-hidden="true"
          className="pointer-events-none absolute inset-0 bg-[radial-gradient(50%_120%_at_20%_50%,rgba(242,180,87,0.16),transparent_70%)]"
        />
        <Marquee speed={40}>
          {MANIFESTO.map((w) => (
            <span key={w} className="flex items-center gap-7 px-7">
              <span className="font-display text-[clamp(1.5rem,3.6vw,2.6rem)] leading-none font-bold tracking-[-0.03em] text-bone-50/90">
                {w}
              </span>
              <span className="text-gold-500/70">
                <Icon name="scissors" size={20} />
              </span>
            </span>
          ))}
        </Marquee>
      </div>

      <div aria-hidden="true" className="pointer-events-none absolute inset-0">
        <div className="absolute inset-0 bg-[radial-gradient(60%_45%_at_12%_10%,rgba(232,155,46,0.14),transparent_60%),radial-gradient(50%_40%_at_95%_85%,rgba(226,96,63,0.1),transparent_60%)]" />
        <div className="grain-layer absolute inset-0 opacity-[0.035] mix-blend-multiply" />
      </div>

      <div className="relative mx-auto w-full max-w-[1400px] px-4 pt-20 sm:px-6 sm:pt-24 lg:px-10">
        <div className="grid gap-14 lg:grid-cols-12 lg:gap-12">
          {/* sticky left */}
          <div className="lg:col-span-5">
            <div className="lg:sticky lg:top-28">
              <SectionHeading
                tone="light"
                eyebrow="Why the chair stays booked"
                title={[
                  <>You're not buying</>,
                  <>
                    software. You're buying <span className="text-gold-600">judgment.</span>
                  </>,
                ]}
                lead="Anyone can assemble a timeline. The reason a film lands is a thousand small decisions about what to cut, when to breathe, and where the story actually is. Here's what that judgment gets you in practice."
              />

              <Reveal delay={160}>
                <figure className="group relative mt-8 overflow-hidden rounded-[16px] border border-ash/18 bg-ink-900">
                  <div className="h-[clamp(190px,34vh,340px)] w-full overflow-hidden">
                    <img
                      src={IMG.suite}
                      alt="Jules Mercier editing in the suite at dual monitors"
                      loading="lazy"
                      decoding="async"
                      className="size-full object-cover transition-transform duration-[1.6s] ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:scale-[1.07]"
                    />
                  </div>
                  <span className="pointer-events-none absolute inset-0 bg-gradient-to-t from-ink-950 via-ink-950/25 to-transparent" />
                  <figcaption className="absolute inset-x-0 bottom-0 flex items-end justify-between gap-4 p-5">
                    <div>
                      <p className="font-mono text-[9.5px] tracking-[0.18em] text-gold-400 uppercase">
                        Suite 02 · Lisbon
                      </p>
                      <p className="mt-1.5 font-display text-xl leading-tight font-bold text-bone-50">
                        Calibrated. Quiet. Nobody else touches your timeline.
                      </p>
                    </div>
                    <span className="hidden shrink-0 font-display text-3xl font-bold text-gold-400/80 italic sm:block">
                      JM
                    </span>
                  </figcaption>
                  <span className="absolute top-4 left-4 inline-flex items-center gap-2 rounded-full border border-jade-500/30 bg-ink-950/60 px-3 py-1.5 backdrop-blur-md">
                    <span className="relative flex size-1.5">
                      <span className="absolute inset-0 rounded-full bg-jade-400 animate-pulse-ring" />
                      <span className="relative size-1.5 rounded-full bg-jade-400" />
                    </span>
                    <span className="font-mono text-[9.5px] tracking-[0.16em] text-jade-400 uppercase">
                      Rendering now
                    </span>
                  </span>
                </figure>
              </Reveal>
            </div>
          </div>

          {/* benefits right */}
          <div className="lg:col-span-7">
            <div className="grid gap-4 sm:grid-cols-2">
              {BENEFITS.map((b, i) => (
                <Reveal key={b.title} delay={(i % 2) * 90} variant="up">
                  <article className="lift group relative h-full overflow-hidden rounded-[15px] border border-ash/16 bg-white/70 p-6 backdrop-blur-sm hover:-translate-y-1.5 hover:border-gold-500/50 hover:bg-white hover:shadow-[0_30px_60px_-38px_rgba(28,20,12,0.85)]">
                    <span
                      aria-hidden="true"
                      className="absolute inset-x-0 top-0 h-[3px] origin-left scale-x-0 bg-gradient-to-r from-gold-500 to-ember-500 transition-transform duration-[600ms] group-hover:scale-x-100"
                    />
                    <div className="flex items-start justify-between gap-4">
                      <span className="grid size-11 place-items-center rounded-[11px] border border-ash/18 bg-bone-100 text-gold-600 transition-all duration-500 group-hover:-rotate-6 group-hover:border-gold-500 group-hover:bg-gold-500 group-hover:text-ink-950">
                        <Icon name={b.icon} size={20} />
                      </span>
                      <span className="text-right">
                        <span className="block font-display text-2xl leading-none font-bold text-ink-900">
                          {b.metric}
                        </span>
                        <span className="mt-1 block max-w-[9rem] font-mono text-[9px] leading-snug tracking-[0.1em] text-ash/70 uppercase">
                          {b.metricLabel}
                        </span>
                      </span>
                    </div>
                    <h3 className="mt-5 font-display text-[1.3rem] leading-tight font-bold tracking-[-0.02em] text-ink-900">
                      {b.title}
                    </h3>
                    <p className="mt-2.5 text-[14.5px] leading-relaxed text-ash">{b.copy}</p>
                  </article>
                </Reveal>
              ))}
            </div>

            <Reveal delay={120}>
              <div className="mt-5 flex flex-col items-start justify-between gap-5 rounded-[15px] border border-ink-900/14 bg-ink-900 p-6 sm:flex-row sm:items-center sm:p-7">
                <div>
                  <p className="font-display text-xl leading-tight font-bold text-bone-50">
                    The guarantee: if the first cut misses the brief, the next round is on me.
                  </p>
                  <p className="mt-2 max-w-lg text-[13.5px] text-smoke">
                    Eleven years, 240 films — it has been invoked twice. Both times the client still
                    paid for the next project.
                  </p>
                </div>
                <button
                  onClick={() => scrollToId("book")}
                  className="btn-sheen group inline-flex shrink-0 items-center gap-2 rounded-full bg-gold-400 px-5 py-3 text-sm font-semibold text-ink-950 transition-all duration-300 hover:-translate-y-0.5 hover:bg-gold-300"
                >
                  <span className="relative z-10">Book the fit call</span>
                  <span className="relative z-10 transition-transform duration-300 group-hover:translate-x-1">
                    <Icon name="arrowRight" size={15} strokeWidth={2} />
                  </span>
                </button>
              </div>
            </Reveal>
          </div>
        </div>

        <Process />
      </div>
    </section>
  );
}

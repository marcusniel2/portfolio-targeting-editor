import { useEffect, useRef, useState } from "react";
import { BRAND, IMG } from "@/lib/data";
import { useLocalTime } from "@/lib/hooks";
import { cn } from "@/utils/cn";
import { Icon } from "./Icon";
import { Eyebrow, MaskLines, Reveal, Timecode } from "./ui";

const PROJECT_TYPES = [
  "Brand film",
  "Documentary",
  "Music video",
  "Social series",
  "Broadcast",
  "Something else",
];

const BUDGETS = ["< €2k", "€2k – 5k", "€5k – 12k", "€12k +", "Monthly retainer"];

const SLOTS = [
  { window: "17 Mar – 28 Mar", state: "open", note: "2 slots · full post" },
  { window: "07 Apr – 18 Apr", state: "open", note: "1 slot · grade only" },
  { window: "May onwards", state: "waitlist", note: "waitlist · retainer priority" },
];

type Form = {
  name: string;
  email: string;
  company: string;
  type: string;
  budget: string;
  timeline: string;
  link: string;
  message: string;
};

const EMPTY: Form = {
  name: "",
  email: "",
  company: "",
  type: "",
  budget: "",
  timeline: "Within 1 month",
  link: "",
  message: "",
};

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i;

function Field({
  id,
  label,
  hint,
  error,
  children,
  className,
  group,
}: {
  id: string;
  label: string;
  hint?: string;
  error?: string;
  children: React.ReactNode;
  className?: string;
  group?: boolean;
}) {
  return (
    <div className={className}>
      <div className="flex items-baseline justify-between gap-3">
        <label
          id={group ? `${id}-label` : undefined}
          htmlFor={group ? undefined : id}
          className="font-mono text-[10px] tracking-[0.18em] text-smoke/75 uppercase"
        >
          {label}
          {hint && <span className="ml-2 normal-case tracking-normal text-smoke/45">{hint}</span>}
        </label>
        {error && (
          <span id={`${id}-err`} className="font-mono text-[10px] text-ember-400">
            {error}
          </span>
        )}
      </div>
      <div
        className="mt-2"
        {...(group
          ? {
              role: "group",
              "aria-labelledby": `${id}-label`,
              "aria-describedby": error ? `${id}-err` : undefined,
            }
          : {})}
      >
        {children}
      </div>
    </div>
  );
}

const inputCls =
  "w-full rounded-[11px] border bg-ink-950/60 px-4 py-3 text-[14.5px] text-bone-50 placeholder:text-smoke/45 transition-all duration-300 outline-none focus:border-gold-400/70 focus:bg-ink-950/85 focus:shadow-[0_0_0_3px_rgba(242,180,87,0.14)]";

export function Booking({ prefill }: { prefill: string }) {
  const [f, setF] = useState<Form>(EMPTY);
  const [errors, setErrors] = useState<Partial<Record<keyof Form, string>>>({});
  const [status, setStatus] = useState<"idle" | "sending" | "sent">("idle");
  const [flash, setFlash] = useState(false);
  const msgRef = useRef<HTMLTextAreaElement | null>(null);
  const time = useLocalTime(BRAND.tz);

  useEffect(() => {
    if (!prefill || f.message.includes("Scope:")) return;
    setF((prev) => ({
      ...prev,
      message: prev.message ? `${prefill}\n\n${prev.message}` : prefill,
    }));
    setFlash(true);
    const id = window.setTimeout(() => setFlash(false), 1600);
    window.setTimeout(() => msgRef.current?.focus({ preventScroll: true }), 500);
    return () => window.clearTimeout(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [prefill]);

  const set = (k: keyof Form, v: string) => {
    setF((prev) => ({ ...prev, [k]: v }));
    setErrors((prev) => ({ ...prev, [k]: undefined }));
  };

  const validate = () => {
    const e: Partial<Record<keyof Form, string>> = {};
    if (f.name.trim().length < 2) e.name = "required";
    if (!EMAIL_RE.test(f.email.trim())) e.email = "check this";
    if (!f.type) e.type = "pick one";
    if (!f.budget) e.budget = "pick one";
    if (f.message.trim().length < 20) e.message = `${20 - f.message.trim().length} chars to go`;
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const submit = (ev: React.FormEvent) => {
    ev.preventDefault();
    if (!validate()) return;
    setStatus("sending");
    window.setTimeout(() => setStatus("sent"), 1200);
  };

  return (
    <section id="book" className="relative isolate overflow-hidden py-20 sm:py-28">
      {/* full-bleed backdrop */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 -z-10">
        <img
          src={IMG.cta}
          alt=""
          loading="lazy"
          className="size-full object-cover opacity-[0.16]"
          style={{ filter: "saturate(0.7) contrast(1.1)" }}
        />
        <div className="absolute inset-0 bg-[radial-gradient(85%_70%_at_20%_10%,rgba(242,180,87,0.18),transparent_60%),linear-gradient(180deg,rgba(12,10,9,0.96),rgba(12,10,9,0.9)_45%,rgba(12,10,9,0.98))]" />
        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-gold-400/40 to-transparent" />
      </div>

      <div className="mx-auto w-full max-w-[1400px] px-4 sm:px-6 lg:px-10">
        <div className="grid gap-12 lg:grid-cols-12 lg:gap-14">
          {/* left */}
          <div className="lg:col-span-5">
            <Reveal>
              <Eyebrow>{BRAND.availability} · replies in 4h</Eyebrow>
            </Reveal>
            <h2 className="mt-6 font-display text-[clamp(2.3rem,5.6vw,3.9rem)] leading-[0.94] tracking-[-0.04em] text-bone-50">
              <MaskLines
                lines={[
                  "Let's find the film",
                  <>
                    inside your <span className="text-gold-400">footage.</span>
                  </>,
                ]}
              />
            </h2>
            <Reveal delay={220}>
              <p className="mt-6 max-w-md text-[1.02rem] leading-[1.75] text-smoke">
                Send the brief, the drive link and two references of work you wish you'd made.
                You'll get a real reply from me — not an assistant — with a fixed price, a start
                date and an honest read on whether the footage can carry the film.
              </p>
            </Reveal>

            <Reveal delay={300}>
              <ul className="mt-9 space-y-2.5">
                {SLOTS.map((s) => (
                  <li
                    key={s.window}
                    className={cn(
                      "group flex items-center justify-between gap-4 rounded-[12px] border px-4 py-3.5 transition-all duration-300 hover:-translate-y-0.5",
                      s.state === "open"
                        ? "border-jade-500/25 bg-jade-500/[0.07] hover:border-jade-400/60"
                        : "border-bone-100/12 bg-ink-950/40 hover:border-bone-100/25",
                    )}
                  >
                    <span className="flex items-center gap-3">
                      <span
                        className={cn(
                          "relative flex size-2",
                          s.state === "open" && "text-jade-400",
                        )}
                      >
                        {s.state === "open" && (
                          <span className="absolute inset-0 rounded-full bg-jade-400 animate-pulse-ring" />
                        )}
                        <span
                          className={cn(
                            "relative size-2 rounded-full",
                            s.state === "open" ? "bg-jade-400" : "bg-smoke/40",
                          )}
                        />
                      </span>
                      <span>
                        <span className="block font-display text-[15px] font-bold text-bone-50">
                          {s.window}
                        </span>
                        <span className="block font-mono text-[9.5px] tracking-[0.14em] text-smoke/70 uppercase">
                          {s.note}
                        </span>
                      </span>
                    </span>
                    <Timecode className={s.state === "open" ? "text-jade-400" : "text-smoke/45"}>
                      {s.state === "open" ? "OPEN" : "WAITLIST"}
                    </Timecode>
                  </li>
                ))}
              </ul>
            </Reveal>

            <Reveal delay={360}>
              <dl className="mt-9 grid gap-px overflow-hidden rounded-[14px] border border-bone-100/10 bg-bone-100/10 sm:grid-cols-3">
                {[
                  { k: "Local time", v: time, icon: "clock" as const },
                  { k: "Email", v: BRAND.email, icon: "mail" as const, href: `mailto:${BRAND.email}` },
                  { k: "Studio", v: `${BRAND.base} · remote`, icon: "pin" as const },
                ].map((c) => (
                  <div key={c.k} className="bg-ink-950/80 px-4 py-4">
                    <dt className="flex items-center gap-2 font-mono text-[9.5px] tracking-[0.16em] text-smoke/65 uppercase">
                      <Icon name={c.icon} size={12} />
                      {c.k}
                    </dt>
                    <dd className="mt-2 truncate text-[13.5px] font-medium text-bone-100">
                      {c.href ? (
                        <a href={c.href} className="hover:text-gold-300">
                          {c.v}
                        </a>
                      ) : (
                        <span className="tabular-nums">{c.v}</span>
                      )}
                    </dd>
                  </div>
                ))}
              </dl>
            </Reveal>
          </div>

          {/* form */}
          <div className="lg:col-span-7">
            <Reveal variant="scale" delay={120}>
              <div className="panel relative overflow-hidden rounded-[20px] p-6 sm:p-8">
                <div className="flex flex-wrap items-center justify-between gap-3 border-b border-bone-100/10 pb-5">
                  <div className="flex items-center gap-3">
                    <span className="grid size-9 place-items-center rounded-full bg-gold-400/12 text-gold-400">
                      <Icon name="scissors" size={17} />
                    </span>
                    <div className="leading-tight">
                      <p className="font-display text-lg font-bold text-bone-50">Project brief</p>
                      <Timecode className="mt-0.5 block text-smoke/65">
                        {status === "sent" ? "RECEIVED" : "6 FIELDS · ~90 SECONDS"}
                      </Timecode>
                    </div>
                  </div>
                  <span className="inline-flex items-center gap-2 rounded-full border border-jade-500/25 bg-jade-500/8 px-3 py-1.5">
                    <Icon name="shield" size={13} className="text-jade-400" />
                    <span className="font-mono text-[9.5px] tracking-[0.14em] text-jade-400 uppercase">
                      NDA on request
                    </span>
                  </span>
                </div>

                {status === "sent" ? (
                  <div className="py-10 text-center">
                    <span className="mx-auto grid size-16 place-items-center rounded-full bg-jade-500/15 text-jade-400">
                      <Icon name="check" size={30} strokeWidth={2} />
                    </span>
                    <h3 className="mt-6 font-display text-[clamp(1.7rem,3.6vw,2.4rem)] leading-none font-bold text-bone-50">
                      Brief received, {f.name.split(" ")[0]}.
                    </h3>
                    <p className="mx-auto mt-3 max-w-md text-[14.5px] leading-relaxed text-smoke">
                      It's queued at{" "}
                      <span className="font-mono text-gold-300">
                        {time}
                      </span>{" "}
                      Lisbon time. I read every brief personally and reply within four business
                      hours — usually with two questions and a start date.
                    </p>
                    <ol className="mx-auto mt-7 max-w-md space-y-2.5 text-left">
                      {[
                        "I ingest your link and sanity-check the footage.",
                        "You get a fixed quote, a start date and a first-cut day.",
                        "We sign a one-page agreement and the slot is yours.",
                      ].map((s, i) => (
                        <li
                          key={s}
                          className="flex items-start gap-3 rounded-[11px] border border-bone-100/10 bg-ink-950/45 px-4 py-3 text-[13.5px] text-bone-200"
                        >
                          <span className="font-mono text-[10px] text-gold-400">0{i + 1}</span>
                          {s}
                        </li>
                      ))}
                    </ol>
                    <button
                      onClick={() => {
                        setF(EMPTY);
                        setStatus("idle");
                      }}
                      className="mt-8 inline-flex items-center gap-2 rounded-full border border-bone-100/15 px-5 py-3 text-sm text-bone-100 transition-colors hover:border-gold-400/60 hover:text-gold-300"
                    >
                      <Icon name="loop" size={15} />
                      Send another brief
                    </button>
                  </div>
                ) : (
                  <form onSubmit={submit} noValidate className="mt-6 grid gap-5 sm:grid-cols-2">
                    <Field id="name" label="Your name" error={errors.name}>
                      <input
                        id="name"
                        name="name"
                        autoComplete="name"
                        value={f.name}
                        onChange={(e) => set("name", e.target.value)}
                        aria-invalid={!!errors.name}
                        aria-describedby={errors.name ? "name-err" : undefined}
                        placeholder="Marta Lindqvist"
                        className={cn(inputCls, errors.name ? "border-ember-500/70" : "border-bone-100/12")}
                      />
                    </Field>

                    <Field id="email" label="Email" error={errors.email}>
                      <input
                        id="email"
                        name="email"
                        type="email"
                        autoComplete="email"
                        value={f.email}
                        onChange={(e) => set("email", e.target.value)}
                        aria-invalid={!!errors.email}
                        aria-describedby={errors.email ? "email-err" : undefined}
                        placeholder="you@studio.com"
                        className={cn(inputCls, errors.email ? "border-ember-500/70" : "border-bone-100/12")}
                      />
                    </Field>

                    <Field id="company" label="Company" hint="optional">
                      <input
                        id="company"
                        name="company"
                        autoComplete="organization"
                        value={f.company}
                        onChange={(e) => set("company", e.target.value)}
                        placeholder="Vantage Athletics"
                        className={cn(inputCls, "border-bone-100/12")}
                      />
                    </Field>

                    <Field id="link" label="Footage / drive link" hint="optional">
                      <input
                        id="link"
                        name="link"
                        type="url"
                        value={f.link}
                        onChange={(e) => set("link", e.target.value)}
                        placeholder="drive.google.com/…"
                        className={cn(inputCls, "border-bone-100/12")}
                      />
                    </Field>

                    <Field
                      id="type"
                      label="Project type"
                      error={errors.type}
                      className="sm:col-span-2"
                      group
                    >
                      <div className="flex flex-wrap gap-2">
                        {PROJECT_TYPES.map((p) => (
                          <button
                            key={p}
                            type="button"
                            onClick={() => set("type", p)}
                            aria-pressed={f.type === p}
                            className={cn(
                              "rounded-full border px-3.5 py-2 text-[12.5px] transition-all duration-300",
                              f.type === p
                                ? "border-gold-400 bg-gold-400 text-ink-950"
                                : "border-bone-100/14 text-smoke hover:-translate-y-0.5 hover:border-gold-400/50 hover:text-bone-50",
                            )}
                          >
                            {p}
                          </button>
                        ))}
                      </div>
                    </Field>

                    <Field
                      id="budget"
                      label="Budget"
                      error={errors.budget}
                      className="sm:col-span-2"
                      group
                    >
                      <div className="flex flex-wrap gap-2">
                        {BUDGETS.map((b) => (
                          <button
                            key={b}
                            type="button"
                            onClick={() => set("budget", b)}
                            aria-pressed={f.budget === b}
                            className={cn(
                              "rounded-full border px-3.5 py-2 font-mono text-[11.5px] tracking-[0.06em] transition-all duration-300",
                              f.budget === b
                                ? "border-jade-400 bg-jade-500/18 text-bone-50"
                                : "border-bone-100/14 text-smoke hover:-translate-y-0.5 hover:border-jade-400/45 hover:text-bone-100",
                            )}
                          >
                            {b}
                          </button>
                        ))}
                      </div>
                    </Field>

                    <Field id="timeline" label="Ideal delivery">
                      <div className="relative">
                        <select
                          id="timeline"
                          name="timeline"
                          value={f.timeline}
                          onChange={(e) => set("timeline", e.target.value)}
                          className={cn(inputCls, "appearance-none border-bone-100/12 pr-10")}
                        >
                          {["ASAP — rush slot", "Within 1 month", "1 – 3 months", "Just exploring"].map(
                            (o) => (
                              <option key={o} value={o} className="bg-ink-900">
                                {o}
                              </option>
                            ),
                          )}
                        </select>
                        <span className="pointer-events-none absolute top-1/2 right-3.5 -translate-y-1/2 text-smoke">
                          <Icon name="chevron" size={15} />
                        </span>
                      </div>
                    </Field>

                    <Field id="message" label="The brief" error={errors.message} hint="what's the film?">
                      <textarea
                        id="message"
                        name="message"
                        rows={4}
                        ref={msgRef}
                        value={f.message}
                        onChange={(e) => set("message", e.target.value)}
                        aria-invalid={!!errors.message}
                        aria-describedby={errors.message ? "message-err" : undefined}
                        placeholder="Two-day shoot, 20 hours of coverage, 3-minute hero film plus six verticals. Launching in April…"
                        className={cn(
                          inputCls,
                          "resize-y leading-relaxed transition-shadow duration-500",
                          errors.message ? "border-ember-500/70" : "border-bone-100/12",
                          flash && "border-gold-400 shadow-[0_0_0_4px_rgba(242,180,87,0.18)]",
                        )}
                      />
                    </Field>

                    <div className="sm:col-span-2">
                      <button
                        type="submit"
                        disabled={status === "sending"}
                        className={cn(
                          "btn-sheen group inline-flex w-full items-center justify-center gap-2.5 rounded-full bg-gold-400 px-7 py-4 font-display text-base font-bold text-ink-950 transition-all duration-300 hover:-translate-y-0.5 hover:bg-gold-300 hover:shadow-[0_20px_50px_-18px_rgba(242,180,87,1)] disabled:cursor-wait disabled:opacity-80",
                        )}
                      >
                        <span className="relative z-10">
                          {status === "sending" ? "Sending brief…" : "Send the brief"}
                        </span>
                        <span
                          className={cn(
                            "relative z-10 transition-transform duration-300",
                            status === "sending" ? "animate-pulse" : "group-hover:translate-x-1",
                          )}
                        >
                          <Icon name={status === "sending" ? "wave" : "arrowRight"} size={17} strokeWidth={2} />
                        </span>
                      </button>
                      <p className="mt-3.5 text-center font-mono text-[9.5px] tracking-[0.14em] text-smoke/60 uppercase">
                        No newsletter, no CRM sequence · your footage stays under NDA · 50% deposit
                        books the slot
                      </p>
                    </div>
                  </form>
                )}
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}

import type { ReactElement, SVGProps } from "react";

export type IconName =
  | "clock"
  | "loop"
  | "shield"
  | "sliders"
  | "tag"
  | "heart"
  | "play"
  | "pause"
  | "arrowRight"
  | "arrowUpRight"
  | "plus"
  | "minus"
  | "chevron"
  | "star"
  | "check"
  | "close"
  | "menu"
  | "film"
  | "wave"
  | "scissors"
  | "mail"
  | "pin"
  | "phone"
  | "drag"
  | "spark";

const P: Record<IconName, ReactElement> = {
  clock: (
    <>
      <path d="M12 3.2a8.8 8.8 0 1 0 8.8 8.8" />
      <path d="M12 7.4V12l3.4 2.2" />
      <path d="M18.4 3.2 21 5.8l-2.6 2.6" />
    </>
  ),
  loop: (
    <>
      <path d="M4.4 9.6A7.6 7.6 0 0 1 18.2 7" />
      <path d="M19.6 14.4A7.6 7.6 0 0 1 5.8 17" />
      <path d="m18.6 3.6-.4 3.4-3.4-.4" />
      <path d="m5.4 20.4.4-3.4 3.4.4" />
    </>
  ),
  shield: (
    <>
      <path d="M12 2.9 4.7 5.6v6c0 4.3 3 8.1 7.3 9.5 4.3-1.4 7.3-5.2 7.3-9.5v-6z" />
      <path d="m8.9 11.9 2.2 2.3 4-4.6" />
    </>
  ),
  sliders: (
    <>
      <path d="M6.5 3.4v6M6.5 13.6v7M12 3.4v3.2M12 10.8v9.8M17.5 3.4v8.4M17.5 16v4.6" />
      <circle cx="6.5" cy="11.5" r="2.1" />
      <circle cx="12" cy="8.7" r="2.1" />
      <circle cx="17.5" cy="13.9" r="2.1" />
    </>
  ),
  tag: (
    <>
      <path d="M11.2 3.3H20a.9.9 0 0 1 .9.9v8.8a1.6 1.6 0 0 1-.5 1.2l-6 5.9a1.6 1.6 0 0 1-2.3 0l-7.4-7.4a1.6 1.6 0 0 1 0-2.3l5.9-6a1.6 1.6 0 0 1 1.2-.5z" />
      <circle cx="16.4" cy="7.7" r="1.5" />
    </>
  ),
  heart: (
    <>
      <path d="M12 20.4 4.9 13.6a4.4 4.4 0 0 1 6.2-6.2l.9.9.9-.9a4.4 4.4 0 0 1 6.2 6.2z" />
    </>
  ),
  play: <path d="M8.2 5.3 18.6 12 8.2 18.7z" />,
  pause: (
    <>
      <path d="M9.2 5v14M14.8 5v14" />
    </>
  ),
  arrowRight: (
    <>
      <path d="M3.6 12h16.2" />
      <path d="m13.6 5.8 6.2 6.2-6.2 6.2" />
    </>
  ),
  arrowUpRight: (
    <>
      <path d="M6.6 17.4 17.4 6.6" />
      <path d="M8.6 6.6h8.8v8.8" />
    </>
  ),
  plus: <path d="M12 4.8v14.4M4.8 12h14.4" />,
  minus: <path d="M4.8 12h14.4" />,
  chevron: <path d="m5.8 9.2 6.2 6.2 6.2-6.2" />,
  star: (
    <path d="m12 3.4 2.6 5.5 6 .8-4.4 4.2 1.1 6-5.3-2.9-5.3 2.9 1.1-6L3.4 9.7l6-.8z" />
  ),
  check: <path d="m4.8 12.6 4.6 4.6L19.4 6.8" />,
  close: <path d="M5.6 5.6 18.4 18.4M18.4 5.6 5.6 18.4" />,
  menu: <path d="M3.6 7.2h16.8M3.6 12h16.8M3.6 16.8h11.4" />,
  film: (
    <>
      <rect x="3.2" y="4.6" width="17.6" height="14.8" rx="1.8" />
      <path d="M7.6 4.6v14.8M16.4 4.6v14.8M3.2 9.4h4.4M3.2 14.6h4.4M16.4 9.4h4.4M16.4 14.6h4.4" />
    </>
  ),
  wave: (
    <>
      <path d="M3 12h1.8M21 12h-1.8" />
      <path d="M7 8.4v7.2M10.4 5.4v13.2M13.8 9.6v4.8M17.2 6.8v10.4" />
    </>
  ),
  scissors: (
    <>
      <circle cx="6.2" cy="17.6" r="2.6" />
      <circle cx="6.2" cy="6.4" r="2.6" />
      <path d="M8.4 8 20 18.4M20 5.6 8.4 16" />
    </>
  ),
  mail: (
    <>
      <rect x="2.9" y="5.2" width="18.2" height="13.6" rx="2" />
      <path d="m3.6 6.6 8.4 6.2 8.4-6.2" />
    </>
  ),
  pin: (
    <>
      <path d="M12 21.2s7-5.6 7-11a7 7 0 1 0-14 0c0 5.4 7 11 7 11z" />
      <circle cx="12" cy="10" r="2.6" />
    </>
  ),
  phone: (
    <path d="M7.4 3.6 9.8 8l-2 2.2a12.4 12.4 0 0 0 6 6l2.2-2 4.4 2.4-1 3.2a1.6 1.6 0 0 1-1.8 1.1C13.2 20.1 3.9 10.8 3.1 5.4a1.6 1.6 0 0 1 1.1-1.8z" />
  ),
  drag: (
    <>
      <path d="M12 3.6v16.8" />
      <path d="m8.4 7.2-3.6 3.6 3.6 3.6" />
      <path d="m15.6 7.2 3.6 3.6-3.6 3.6" />
    </>
  ),
  spark: (
    <>
      <path d="M12 3.2 13.7 9l5.8 1.7-5.8 1.7L12 18.2 10.3 12.4 4.5 10.7 10.3 9z" />
      <path d="M18.6 16.4 19.3 18.7 21.6 19.4 19.3 20.1 18.6 22.4 17.9 20.1 15.6 19.4 17.9 18.7z" />
    </>
  ),
};

type Props = SVGProps<SVGSVGElement> & { name: IconName; size?: number };

export function Icon({ name, size = 22, strokeWidth = 1.5, ...rest }: Props) {
  const filled = name === "play" || name === "star";
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill={filled ? "currentColor" : "none"}
      stroke="currentColor"
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      focusable="false"
      {...rest}
    >
      {P[name]}
    </svg>
  );
}

/** Wordmark monogram — cut mark + record dot. */
export function Monogram({ className = "", size = 34 }: { className?: string; size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 40 40" className={className} aria-hidden="true">
      <rect width="40" height="40" rx="9" fill="#181514" />
      <rect
        x="0.6"
        y="0.6"
        width="38.8"
        height="38.8"
        rx="8.6"
        fill="none"
        stroke="currentColor"
        strokeOpacity="0.28"
        strokeWidth="1.2"
      />
      <path d="M10 13.5h5.6l3.8 8.2 3.8-8.2H28.8l-6.7 13H16.7z" fill="#F2B457" />
      <circle cx="28.4" cy="28" r="3.1" fill="#4FB8A0" />
    </svg>
  );
}

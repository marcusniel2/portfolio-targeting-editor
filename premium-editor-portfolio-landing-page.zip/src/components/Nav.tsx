import { useEffect, useState } from "react";
import { BRAND, NAV_LINKS } from "@/lib/data";
import { scrollToId, useActiveSection, useScrollProgress, useScrollY } from "@/lib/hooks";
import { cn } from "@/utils/cn";
import { Icon, Monogram } from "./Icon";

const IDS = NAV_LINKS.map((l) => l.id);

export function Nav() {
  const y = useScrollY();
  const progress = useScrollProgress();
  const active = useActiveSection(IDS);
  const [open, setOpen] = useState(false);
  const stuck = y > 28;

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const [bar, setBar] = useState(false);
  useEffect(() => {
    const on = () => {
      const book = document.getElementById("book");
      const bookNear = book
        ? book.getBoundingClientRect().top < window.innerHeight * 0.85
        : false;
      setBar(window.scrollY > window.innerHeight * 0.85 && !bookNear && !open);
    };
    on();
    window.addEventListener("scroll", on, { passive: true });
    window.addEventListener("resize", on);
    return () => {
      window.removeEventListener("scroll", on);
      window.removeEventListener("resize", on);
    };
  }, [open]);

  const go = (id: string) => {
    setOpen(false);
    window.setTimeout(() => scrollToId(id), open ? 220 : 0);
  };

  return (
    <>
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:z-[80] focus:rounded-full focus:bg-gold-400 focus:px-5 focus:py-2.5 focus:text-sm focus:font-semibold focus:text-ink-950"
      >
        Skip to content
      </a>

      <header
        className={cn(
          "fixed inset-x-0 top-0 z-50 transition-all duration-500",
          stuck ? "py-2" : "py-4 sm:py-5",
        )}
      >
        <div className="mx-auto w-full max-w-[1400px] px-4 sm:px-6 lg:px-10">
          <div
            className={cn(
              "relative flex items-center justify-between gap-4 rounded-full border px-3 py-2 transition-all duration-500 sm:px-4",
              stuck
                ? "border-bone-100/12 bg-ink-950/72 shadow-[0_18px_50px_-28px_rgba(0,0,0,1)] backdrop-blur-xl"
                : "border-transparent bg-transparent",
            )}
          >
            {/* brand */}
            <button
              onClick={() => go("hero")}
              className="group flex items-center gap-3 rounded-full pr-2 text-left"
              aria-label={`${BRAND.name} — back to top`}
            >
              <span className="text-gold-400/40 transition-colors duration-500 group-hover:text-gold-400">
                <Monogram size={stuck ? 32 : 36} className="transition-all duration-500" />
              </span>
              <span className="hidden leading-none sm:block">
                <span className="block font-display text-[0.98rem] font-bold tracking-tight text-bone-50">
                  {BRAND.name}
                </span>
                <span className="mt-1 block font-mono text-[9.5px] tracking-[0.2em] text-smoke/75 uppercase">
                  {BRAND.role}
                </span>
              </span>
            </button>

            {/* desktop links */}
            <nav aria-label="Primary" className="hidden items-center gap-1 lg:flex">
              {NAV_LINKS.map((l) => (
                <button
                  key={l.id}
                  onClick={() => go(l.id)}
                  data-active={active === l.id}
                  className={cn(
                    "underline-slide relative rounded-full px-3.5 py-2 text-[13.5px] font-medium transition-colors duration-300",
                    active === l.id ? "text-gold-300" : "text-smoke hover:text-bone-50",
                  )}
                >
                  {l.label}
                </button>
              ))}
            </nav>

            <div className="flex items-center gap-2 sm:gap-3">
              <span className="hidden items-center gap-2 rounded-full border border-jade-500/25 bg-jade-500/8 px-3 py-1.5 xl:inline-flex">
                <span className="relative flex size-1.5">
                  <span className="absolute inset-0 rounded-full bg-jade-400 animate-pulse-ring" />
                  <span className="relative size-1.5 rounded-full bg-jade-400" />
                </span>
                <span className="font-mono text-[10px] tracking-[0.16em] text-jade-400 uppercase">
                  {BRAND.availability}
                </span>
              </span>

              <button
                onClick={() => go("book")}
                className="btn-sheen group hidden items-center gap-2 rounded-full bg-gold-400 px-5 py-2.5 text-[13.5px] font-semibold text-ink-950 transition-all duration-300 hover:-translate-y-0.5 hover:bg-gold-300 hover:shadow-[0_16px_40px_-16px_rgba(242,180,87,0.95)] sm:inline-flex"
              >
                <span className="relative z-10">Start a project</span>
                <span className="relative z-10 transition-transform duration-300 group-hover:translate-x-0.5">
                  <Icon name="arrowRight" size={15} strokeWidth={2} />
                </span>
              </button>

              <button
                onClick={() => setOpen((o) => !o)}
                className="flex size-10 items-center justify-center rounded-full border border-bone-100/14 text-bone-100 transition-colors hover:border-gold-400/50 hover:text-gold-300 lg:hidden"
                aria-expanded={open}
                aria-label={open ? "Close menu" : "Open menu"}
              >
                <Icon name={open ? "close" : "menu"} size={19} strokeWidth={1.7} />
              </button>
            </div>

            {/* scroll progress */}
            <span
              aria-hidden="true"
              className={cn(
                "absolute inset-x-4 -bottom-px h-px origin-left rounded-full bg-gradient-to-r from-gold-500 via-ember-500 to-jade-500 transition-opacity duration-500",
                stuck ? "opacity-100" : "opacity-0",
              )}
              style={{ transform: `scaleX(${progress})` }}
            />
          </div>
        </div>
      </header>

      {/* mobile sheet */}
      <div
        className={cn(
          "fixed inset-0 z-40 lg:hidden",
          open ? "pointer-events-auto" : "pointer-events-none",
        )}
        inert={!open}
      >
        <div
          className={cn(
            "absolute inset-0 bg-ink-950/92 backdrop-blur-xl transition-opacity duration-[400ms]",
            open ? "opacity-100" : "opacity-0",
          )}
          onClick={() => setOpen(false)}
        />
        <nav
          aria-label="Mobile"
          className={cn(
            "relative flex h-full flex-col justify-between px-6 pt-28 pb-10 transition-transform duration-500 ease-[cubic-bezier(0.16,1,0.3,1)]",
            open ? "translate-y-0" : "-translate-y-4",
          )}
        >
          <ul className="space-y-1">
            {NAV_LINKS.map((l, i) => (
              <li
                key={l.id}
                className="overflow-hidden"
                style={{
                  transitionDelay: `${120 + i * 60}ms`,
                  opacity: open ? 1 : 0,
                  transform: open ? "none" : "translateY(110%)",
                  transition: "opacity .5s ease, transform .6s cubic-bezier(0.16,1,0.3,1)",
                }}
              >
                <button
                  onClick={() => go(l.id)}
                  className="group flex w-full items-baseline gap-4 border-b border-bone-100/8 py-3.5 text-left"
                >
                  <span className="font-mono text-[10px] text-gold-500/80">0{i + 1}</span>
                  <span className="font-display text-[2rem] font-bold tracking-tight text-bone-50 transition-colors group-hover:text-gold-300">
                    {l.label}
                  </span>
                  <span className="ml-auto self-center text-smoke/40 transition-transform duration-300 group-hover:translate-x-1">
                    <Icon name="arrowUpRight" size={18} />
                  </span>
                </button>
              </li>
            ))}
          </ul>

          <div
            className="space-y-4"
            style={{
              opacity: open ? 1 : 0,
              transform: open ? "none" : "translateY(20px)",
              transition: "opacity .6s ease .45s, transform .6s cubic-bezier(0.16,1,0.3,1) .45s",
            }}
          >
            <button
              onClick={() => go("book")}
              className="btn-sheen flex w-full items-center justify-center gap-2 rounded-full bg-gold-400 px-6 py-4 font-display text-lg font-bold text-ink-950"
            >
              <span className="relative z-10">Start a project</span>
              <span className="relative z-10">
                <Icon name="arrowRight" size={18} strokeWidth={2} />
              </span>
            </button>
            <div className="flex flex-wrap items-center justify-between gap-3 font-mono text-[11px] text-smoke">
              <a href={`mailto:${BRAND.email}`} className="hover:text-gold-300">
                {BRAND.email}
              </a>
              <span className="inline-flex items-center gap-2">
                <span className="size-1.5 rounded-full bg-jade-400" />
                {BRAND.availability}
              </span>
            </div>
          </div>
        </nav>
      </div>

      {/* sticky conversion bar (small screens) */}
      <div
        className={cn(
          "fixed inset-x-0 bottom-0 z-40 px-3 transition-all duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] lg:hidden",
          bar ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-full opacity-0",
        )}
        style={{ paddingBottom: "max(env(safe-area-inset-bottom), 0.75rem)" }}
        aria-hidden={!bar}
      >
        <div className="flex items-center gap-3 rounded-full border border-bone-100/12 bg-ink-950/88 py-2 pr-2 pl-4 shadow-[0_-10px_40px_-20px_rgba(0,0,0,1)] backdrop-blur-xl">
          <span className="relative flex size-2 shrink-0">
            <span className="absolute inset-0 rounded-full bg-jade-400 animate-pulse-ring" />
            <span className="relative size-2 rounded-full bg-jade-400" />
          </span>
          <span className="min-w-0 flex-1 leading-tight">
            <span className="block truncate font-display text-[13px] font-bold text-bone-50">
              {BRAND.availability}
            </span>
            <span className="block font-mono text-[9px] tracking-[0.16em] text-smoke/70 uppercase">
              first cut in 72h
            </span>
          </span>
          <button
            onClick={() => go("book")}
            tabIndex={bar ? 0 : -1}
            className="btn-sheen inline-flex shrink-0 items-center gap-1.5 rounded-full bg-gold-400 px-4 py-2.5 text-[13px] font-semibold text-ink-950"
          >
            <span className="relative z-10">Book</span>
            <span className="relative z-10">
              <Icon name="arrowRight" size={14} strokeWidth={2} />
            </span>
          </button>
        </div>
      </div>
    </>
  );
}

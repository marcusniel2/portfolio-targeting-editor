import type { ElementType, ReactNode } from "react";
import { useInView } from "@/lib/hooks";
import { cn } from "@/utils/cn";
import { Icon, type IconName } from "./Icon";

/* ---------------- scroll reveal ---------------- */

type RevealProps = {
  children: ReactNode;
  className?: string;
  delay?: number;
  variant?: "up" | "left" | "right" | "scale";
  as?: ElementType;
  threshold?: number;
  id?: string;
};

export function Reveal({
  children,
  className,
  delay = 0,
  variant = "up",
  as: Tag = "div",
  threshold = 0.16,
  id,
}: RevealProps) {
  const { ref, inView } = useInView<HTMLDivElement>({ threshold });
  return (
    <Tag
      id={id}
      ref={ref}
      className={cn(
        "reveal",
        variant === "left" && "reveal-left",
        variant === "right" && "reveal-right",
        variant === "scale" && "reveal-scale",
        inView && "is-in",
        className,
      )}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </Tag>
  );
}

/* ---------------- masked line-by-line heading ---------------- */

export function MaskLines({
  lines,
  className,
  lineClassName,
  stagger = 110,
  delay = 0,
}: {
  lines: ReactNode[];
  className?: string;
  lineClassName?: string;
  stagger?: number;
  delay?: number;
}) {
  const { ref, inView } = useInView<HTMLSpanElement>({ threshold: 0.25 });
  return (
    <span ref={ref} className={cn("block", className)}>
      {lines.map((line, i) => (
        <span
          key={i}
          className={cn("line-mask", inView && "is-in", lineClassName)}
          style={{ transitionDelay: `${delay + i * stagger}ms` }}
        >
          <span style={{ transitionDelay: `${delay + i * stagger}ms` }}>{line}</span>
        </span>
      ))}
    </span>
  );
}

/* ---------------- eyebrow / section heading ---------------- */

export function Eyebrow({
  children,
  tone = "dark",
  className,
  dot = true,
}: {
  children: ReactNode;
  tone?: "dark" | "light";
  className?: string;
  dot?: boolean;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-2.5 font-mono text-[11px] tracking-[0.22em] uppercase",
        tone === "dark" ? "text-gold-400" : "text-gold-600",
        className,
      )}
    >
      {dot && (
        <span className="relative flex size-1.5">
          <span className="absolute inset-0 rounded-full bg-current animate-pulse-ring" />
          <span className="relative size-1.5 rounded-full bg-current" />
        </span>
      )}
      {children}
    </span>
  );
}

export function SectionHeading({
  eyebrow,
  title,
  lead,
  tone = "dark",
  align = "left",
  aside,
  className,
}: {
  eyebrow: string;
  title: ReactNode[];
  lead?: ReactNode;
  tone?: "dark" | "light";
  align?: "left" | "center";
  aside?: ReactNode;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "flex flex-col gap-8 lg:flex-row lg:items-end lg:justify-between",
        align === "center" && "lg:flex-col lg:items-center lg:text-center",
        className,
      )}
    >
      <div className={cn("max-w-2xl", align === "center" && "mx-auto")}>
        <Reveal>
          <Eyebrow tone={tone}>{eyebrow}</Eyebrow>
        </Reveal>
        <MaskLines
          lines={title}
          className={cn(
            "mt-5 font-display text-[clamp(2.1rem,5.4vw,4rem)] leading-[0.94] tracking-[-0.035em]",
            tone === "dark" ? "text-bone-50" : "text-ink-900",
          )}
        />
        {lead && (
          <Reveal delay={140}>
            <p
              className={cn(
                "mt-6 text-base leading-relaxed sm:text-[1.0625rem]",
                tone === "dark" ? "text-smoke" : "text-ash",
              )}
            >
              {lead}
            </p>
          </Reveal>
        )}
      </div>
      {aside && <Reveal delay={200}>{aside}</Reveal>}
    </div>
  );
}

/* ---------------- buttons ---------------- */

type BtnProps = {
  children: ReactNode;
  href?: string;
  onClick?: () => void;
  variant?: "gold" | "ghost" | "ink" | "outlineLight";
  size?: "sm" | "md" | "lg";
  icon?: IconName;
  className?: string;
  type?: "button" | "submit";
  disabled?: boolean;
  ariaLabel?: string;
};

export function Button({
  children,
  href,
  onClick,
  variant = "gold",
  size = "md",
  icon,
  className,
  type = "button",
  disabled,
  ariaLabel,
}: BtnProps) {
  const base =
    "btn-sheen group inline-flex items-center justify-center gap-2.5 rounded-full font-medium tracking-tight transition-all duration-300 disabled:cursor-not-allowed disabled:opacity-60";
  const sizes = {
    sm: "px-4 py-2 text-[13px]",
    md: "px-6 py-3 text-sm",
    lg: "px-7 py-3.5 text-[0.95rem]",
  };
  const variants = {
    gold: "bg-gold-400 text-ink-950 hover:bg-gold-300 shadow-[0_10px_36px_-14px_rgba(242,180,87,0.85)] hover:shadow-[0_18px_46px_-14px_rgba(242,180,87,0.95)] hover:-translate-y-0.5",
    ghost:
      "border border-bone-100/18 text-bone-100 hover:border-gold-400/60 hover:text-gold-300 hover:-translate-y-0.5 bg-bone-50/[0.02]",
    outlineLight:
      "border border-ash/30 text-ink-900 hover:border-ink-900 hover:bg-ink-900 hover:text-bone-50 hover:-translate-y-0.5",
    ink: "bg-ink-900 text-bone-50 hover:bg-ink-800 hover:-translate-y-0.5 shadow-[0_12px_34px_-18px_rgba(0,0,0,0.9)]",
  };
  const cls = cn(base, sizes[size], variants[variant], className);
  const inner = (
    <>
      <span className="relative z-10">{children}</span>
      {icon && (
        <span className="relative z-10 transition-transform duration-300 group-hover:translate-x-1">
          <Icon name={icon} size={size === "sm" ? 15 : 17} />
        </span>
      )}
    </>
  );
  if (href) {
    return (
      <a href={href} className={cls} aria-label={ariaLabel} onClick={onClick}>
        {inner}
      </a>
    );
  }
  return (
    <button type={type} onClick={onClick} className={cls} disabled={disabled} aria-label={ariaLabel}>
      {inner}
    </button>
  );
}

/* ---------------- infinite marquee ---------------- */

export function Marquee({
  children,
  reverse = false,
  speed = 48,
  className,
  pauseOnHover = true,
}: {
  children: ReactNode;
  reverse?: boolean;
  speed?: number;
  className?: string;
  pauseOnHover?: boolean;
}) {
  return (
    <div className={cn("marquee-mask relative overflow-hidden", className)}>
      <div
        className="marquee-track"
        style={{
          animation: `${reverse ? "marquee-rev" : "marquee"} ${speed}s linear infinite`,
          animationPlayState: pauseOnHover ? undefined : "running",
        }}
      >
        <div className="flex shrink-0">{children}</div>
        <div className="flex shrink-0" aria-hidden="true">
          {children}
        </div>
      </div>
    </div>
  );
}

/* ---------------- ambient layers ---------------- */

export function GrainLayer() {
  return (
    <div
      aria-hidden="true"
      className="grain-layer pointer-events-none fixed inset-[-60%] z-[60] opacity-[0.055] mix-blend-soft-light animate-grain"
    />
  );
}

export function Timecode({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <span className={cn("font-mono text-[11px] tracking-[0.16em] tabular-nums", className)}>
      {children}
    </span>
  );
}

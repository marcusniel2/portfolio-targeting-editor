/** All site copy + assets in one place. Imagery via Pexels CDN (remote, keeps bundle lean). */

export const BRAND = {
  name: "Jules Mercier",
  first: "Jules",
  last: "Mercier",
  role: "Picture Editor & Colorist",
  base: "Lisbon, PT",
  tz: "Europe/Lisbon",
  email: "cut@julesmercier.studio",
  phone: "+351 912 004 118",
  availability: "2 slots left — March",
  since: 2015,
} as const;

export const IMG = {
  suite: "https://images.pexels.com/photos/8100058/pexels-photo-8100058.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1000&w=1200",
  suiteWide:
    "https://images.pexels.com/photos/8102675/pexels-photo-8102675.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  suiteSolo:
    "https://images.pexels.com/photos/8100067/pexels-photo-8100067.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  tea: "https://images.pexels.com/photos/8100061/pexels-photo-8100061.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  // hero scrub sequence — one night reel
  reel: [
    "https://images.pexels.com/photos/19665186/pexels-photo-19665186.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1400",
    "https://images.pexels.com/photos/37911520/pexels-photo-37911520.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1400",
    "https://images.pexels.com/photos/32260696/pexels-photo-32260696.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1400",
    "https://images.pexels.com/photos/31208770/pexels-photo-31208770.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1400",
    "https://images.pexels.com/photos/16158304/pexels-photo-16158304.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1400",
    "https://images.pexels.com/photos/20596898/pexels-photo-20596898.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1400",
  ],
  grade:
    "https://images.pexels.com/photos/36806859/pexels-photo-36806859.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1500",
  aerial:
    "https://images.pexels.com/photos/12545536/pexels-photo-12545536.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=700&w=1400",
  cta: "https://images.pexels.com/photos/16077169/pexels-photo-16077169.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1400",
} as const;

export const NAV_LINKS = [
  { id: "work", label: "Work" },
  { id: "services", label: "Services" },
  { id: "why", label: "Why me" },
  { id: "voices", label: "Clients" },
  { id: "rates", label: "Rates" },
  { id: "faq", label: "FAQ" },
] as const;

export const CLIENTS = [
  "NORTHWIND",
  "Kestrel Studio",
  "LUMA°",
  "Atlas Coffee Co.",
  "VANTAGE",
  "Meridian Films",
  "OKTA",
  "Sable & Co",
  "Fieldnote",
  "RIVET",
  "Halo Health",
  "Basecamp Media",
  "SÖND",
  "Pallas Records",
] as const;

export type Stat = {
  value: number;
  suffix?: string;
  label: string;
  sub: string;
  decimals?: number;
};

export const STATS: Stat[] = [
  { value: 240, suffix: "+", label: "Films delivered", sub: "since 2015" },
  { value: 11, suffix: " yrs", label: "In the chair", sub: "post-production" },
  { value: 1.2, suffix: "B", label: "Views cut for", sub: "client campaigns", decimals: 1 },
  { value: 96, suffix: "%", label: "Clients return", sub: "for the next film" },
];

export type Service = {
  no: string;
  title: string;
  tag: string;
  blurb: string;
  deliverables: string[];
  tools: string[];
  turnaround: string;
  image: string;
};

export const SERVICES: Service[] = [
  {
    no: "01",
    title: "Narrative & commercial editing",
    tag: "The spine of it",
    blurb:
      "Story-first assembly from whatever you shot. I find the film hiding inside 40 hours of coverage, then cut it tight enough that nobody reaches for their phone.",
    deliverables: [
      "Paper edit + selects from all footage",
      "Assembly → first cut → locked picture",
      "Pacing mapped to your hook window",
      "Chaptered Frame.io reviews",
    ],
    tools: ["Premiere Pro", "Resolve", "Frame.io"],
    turnaround: "First cut in 72h",
    image: IMG.suiteSolo,
  },
  {
    no: "02",
    title: "Color grading",
    tag: "The look",
    blurb:
      "Log to legal in a calibrated suite. Shot-matching across bodies, a LUT bank built for your brand, and skin tones that survive every phone screen on earth.",
    deliverables: [
      "ACES / Rec.709 / Rec.2020 pipelines",
      "Shot-match + power windows, tracked",
      "Custom LUT bank delivered to you",
      "HDR10 pass on request",
    ],
    tools: ["DaVinci Resolve", " calibrated EIZO", "Colourlab"],
    turnaround: "48h after lock",
    image: IMG.grade,
  },
  {
    no: "03",
    title: "Sound design & mix",
    tag: "The reason it feels expensive",
    blurb:
      "Dialogue cleaned, room tone rebuilt, score licensed and mixed. Broadcast-safe at −14 LUFS, or loudness-targeted per platform.",
    deliverables: [
      "Dialogue de-noise, de-ess, de-reverb",
      "Foley, atmos beds, transition design",
      "Stems + full mix, platform-targeted LUFS",
      "Music clearance paperwork",
    ],
    tools: ["Pro Tools", "Audition", "iZotope RX"],
    turnaround: "Bundled with grade",
    image: IMG.tea,
  },
  {
    no: "04",
    title: "Motion graphics & titles",
    tag: "The polish",
    blurb:
      "Lower thirds, kinetic type, data callouts and idents built to your brand's type system — animated with restraint, never templated.",
    deliverables: [
      "Type-driven title sequences",
      "Branded lower thirds + end cards",
      "Data visualisation / product callouts",
      "Editable AE project handed over",
    ],
    tools: ["After Effects", "Illustrator", "Cavalry"],
    turnaround: "+2 days",
    image: IMG.aerial,
  },
  {
    no: "05",
    title: "Vertical & social cutdowns",
    tag: "The reach",
    blurb:
      "One master, twelve placements. I recut — not just crop — so 9:16 holds its own hook, its own rhythm and its own subtitles.",
    deliverables: [
      "9:16 / 4:5 / 1:1 / 16:9 masters",
      "Hook rewrite in the first 1.2 seconds",
      "Burned or sidecar captions, 12 languages",
      "Thumbnail + cover-frame options",
    ],
    tools: ["Premiere Pro", "CapCut Pro", "Subcap"],
    turnaround: "24h per cutdown",
    image: IMG.suiteWide,
  },
  {
    no: "06",
    title: "Post supervision & delivery",
    tag: "The part nobody thanks you for",
    blurb:
      "Specs, codecs, QC, versioning and archive. I talk to your broadcaster, DSP, ad platform and legal team so you never have to.",
    deliverables: [
      "Delivery spec audit per platform",
      "Automated QC + legalisation pass",
      "Versioned masters, proxies, project archive",
      "6-month LTO / cloud backup included",
    ],
    tools: ["Frame.io", "Media Encoder", "Shotgun"],
    turnaround: "Ongoing",
    image: IMG.suite,
  },
];

export type Project = {
  id: string;
  title: string;
  client: string;
  category: "Brand Films" | "Documentary" | "Music" | "Social";
  year: string;
  runtime: string;
  role: string;
  metric: string;
  metricLabel: string;
  blurb: string;
  image: string;
  span: string;
  aspect: string;
};

export const PROJECTS: Project[] = [
  {
    id: "hollow-season",
    title: "Hollow Season",
    client: "Meridian Films",
    category: "Documentary",
    year: "2025",
    runtime: "48:12",
    role: "Editor · Grade · Mix",
    metric: "Sundance",
    metricLabel: "official selection",
    blurb:
      "Eleven months of footage from a vanishing fishing coast, cut into a 48-minute portrait. Built entirely on observed sound — no narrator, no score until minute 19.",
    image: "https://images.pexels.com/photos/19139425/pexels-photo-19139425.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200",
    span: "lg:col-span-7",
    aspect: "aspect-[16/10]",
  },
  {
    id: "vantage-ss26",
    title: "Vantage SS26",
    client: "Vantage Athletics",
    category: "Brand Films",
    year: "2026",
    runtime: "02:04",
    role: "Editor · Colorist",
    metric: "+38%",
    metricLabel: "checkout rate",
    blurb:
      "A campaign film cut to a 112bpm reference before the shoot even happened. Every transition lands on a downbeat, and the grade runs one palette: sun-bleached chrome.",
    image: "https://images.pexels.com/photos/11493117/pexels-photo-11493117.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200",
    span: "lg:col-span-5",
    aspect: "aspect-[4/5]",
  },
  {
    id: "nightbus",
    title: "Nightbus",
    client: "Pallas Records",
    category: "Music",
    year: "2025",
    runtime: "03:41",
    role: "Editor · VFX · Grade",
    metric: "4.2M",
    metricLabel: "views, 6 weeks",
    blurb:
      "Single-take illusion stitched from 34 setups, speed-ramped to the hi-hat. Bleach-bypass grade with a jade shift on the lows.",
    image: "https://images.pexels.com/photos/11685319/pexels-photo-11685319.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200",
    span: "lg:col-span-5",
    aspect: "aspect-[4/3]",
  },
  {
    id: "kestrel-origin",
    title: "Kestrel: Origin",
    client: "Kestrel Studio",
    category: "Brand Films",
    year: "2025",
    runtime: "01:30",
    role: "Editor · Motion · Grade",
    metric: "Cannes",
    metricLabel: "shortlist, craft",
    blurb:
      "Product launch film for a hardware startup that had no product shots yet. Half the frame is CG plate work, matched so cleanly nobody in the comments noticed.",
    image: "https://images.pexels.com/photos/37911516/pexels-photo-37911516.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200",
    span: "lg:col-span-7",
    aspect: "aspect-[16/10]",
  },
  {
    id: "fieldnote",
    title: "Fieldnote Vol. III",
    client: "Fieldnote",
    category: "Documentary",
    year: "2024",
    runtime: "22:07",
    role: "Editor · Sound design",
    metric: "9 days",
    metricLabel: "shoot to delivery",
    blurb:
      "Shot on location in Nepal with one body and no sound recordist. I rebuilt the entire atmos bed from location wild tracks and library foley.",
    image: "https://images.pexels.com/photos/16663329/pexels-photo-16663329.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200",
    span: "lg:col-span-4",
    aspect: "aspect-[3/4]",
  },
  {
    id: "luma-drop",
    title: "Luma Drop",
    client: "LUMA°",
    category: "Social",
    year: "2026",
    runtime: "00:18 ×12",
    role: "Editor · Captions",
    metric: "12.6M",
    metricLabel: "organic reach",
    blurb:
      "One 90-second master recut into twelve verticals, each with its own hook, its own caption rhythm and its own end frame. Shipped in four days.",
    image: "https://images.pexels.com/photos/8004315/pexels-photo-8004315.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200",
    span: "lg:col-span-4",
    aspect: "aspect-[3/4]",
  },
  {
    id: "atlas-roast",
    title: "Atlas Roast",
    client: "Atlas Coffee Co.",
    category: "Brand Films",
    year: "2024",
    runtime: "02:48",
    role: "Editor · Grade",
    metric: "3 yrs",
    metricLabel: "still running",
    blurb:
      "Origin-trip brand film shot across two continents. Warm, grainy, handheld — and the master has been running unedited on their homepage for three years.",
    image: "https://images.pexels.com/photos/14793008/pexels-photo-14793008.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1200",
    span: "lg:col-span-4",
    aspect: "aspect-[3/4]",
  },
];

export const CATEGORIES = ["All", "Brand Films", "Documentary", "Music", "Social"] as const;

export type Grade = { id: string; name: string; note: string; filter: string };

export const GRADES: Grade[] = [
  { id: "log", name: "Camera LOG", note: "as delivered, flat & legal", filter: "saturate(0.28) contrast(0.78) brightness(1.12) sepia(0.16)" },
  { id: "teal", name: "Teal & Ember", note: "house look · night exteriors", filter: "saturate(1.22) contrast(1.16) hue-rotate(-6deg) brightness(0.98)" },
  { id: "bleach", name: "Bleach Bypass", note: "music video · hard highlight roll-off", filter: "saturate(0.62) contrast(1.5) brightness(1.02)" },
  { id: "golden", name: "Golden Hour", note: "brand film · skin-forward", filter: "saturate(1.18) contrast(1.06) sepia(0.24) brightness(1.04)" },
  { id: "rec709", name: "Clean Rec.709", note: "broadcast-safe · neutral", filter: "saturate(1.04) contrast(1.05) brightness(1)" },
];

export const PROCESS = [
  { step: "01", title: "Fit call", detail: "20 minutes. We find out if the film is a fit — no deck, no pitch theatre." },
  { step: "02", title: "Footage in", detail: "Drive link, spec sheet, references. I ingest, sync, proxy and log the same day." },
  { step: "03", title: "First cut · 72h", detail: "A complete, watchable cut on Frame.io with timestamped notes from me." },
  { step: "04", title: "Refine", detail: "Your notes in one pass, not forty threads. Usually two rounds to lock." },
  { step: "05", title: "Grade & mix", detail: "Calibrated suite, legal levels, LUT bank handed over with the master." },
  { step: "06", title: "Delivery", detail: "Every spec, every aspect ratio, archived and backed up for six months." },
];

export type Benefit = {
  icon: "clock" | "loop" | "shield" | "sliders" | "tag" | "heart";
  title: string;
  copy: string;
  metric: string;
  metricLabel: string;
};

export const BENEFITS: Benefit[] = [
  {
    icon: "clock",
    title: "First cut in 72 hours",
    copy: "Not a mood board, not a call — a complete watchable cut, three days after your footage lands. Momentum is the whole job.",
    metric: "72h",
    metricLabel: "median first-cut time, last 40 projects",
  },
  {
    icon: "loop",
    title: "Revisions that actually converge",
    copy: "Notes live on Frame.io, timestamped, in one thread. Three rounds included on every project and 8 of 10 films lock in two.",
    metric: "2.1",
    metricLabel: "average rounds to picture lock",
  },
  {
    icon: "shield",
    title: "Nothing that can't be legally aired",
    copy: "Licensed music, cleared archive, model releases checked before delivery. Broadcast QC passes on the first submission, every time.",
    metric: "0",
    metricLabel: "QC rejections since 2019",
  },
  {
    icon: "sliders",
    title: "One person, calibrated suite",
    copy: "No handoff to a junior, no outsourced grade. Your film is cut, coloured and mixed by the person you spoke to on day one.",
    metric: "1:1",
    metricLabel: "you work directly with the editor",
  },
  {
    icon: "tag",
    title: "Flat project rates",
    copy: "You know the number before we start. Scope is written down, overages are quoted in advance, and there is no hourly meter running.",
    metric: "100%",
    metricLabel: "of projects billed at quoted price",
  },
  {
    icon: "heart",
    title: "The relationship outlives the render",
    copy: "Masters, project files, LUTs and stems are archived and handed over. Six months of backup included, forever-accessible on request.",
    metric: "96%",
    metricLabel: "of clients book the next film",
  },
];

export type Testimonial = {
  quote: string;
  name: string;
  role: string;
  company: string;
  avatar: string;
  project: string;
  rating: number;
};

export const TESTIMONIALS: Testimonial[] = [
  {
    quote:
      "We handed Jules 34 hours of unusable-feeling coverage and got back a film that made our board cry. The first cut arrived in 61 hours. I have stopped hiring agencies for this.",
    name: "Marta Lindqvist",
    role: "Head of Brand",
    company: "Vantage Athletics",
    avatar: "https://images.pexels.com/photos/33680700/pexels-photo-33680700.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=300&w=300",
    project: "Vantage SS26",
    rating: 5,
  },
  {
    quote:
      "The grade is the reason people ask who shot it. Jules built us a LUT bank that our whole content team now uses — that alone paid for the project twice over.",
    name: "Daniel Okoye",
    role: "Creative Director",
    company: "Kestrel Studio",
    avatar: "https://images.pexels.com/photos/16881939/pexels-photo-16881939.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=300&w=300",
    project: "Kestrel: Origin",
    rating: 5,
  },
  {
    quote:
      "Documentary editors usually want a year. Jules cut 22 minutes of Nepal in nine days and rebuilt the entire sound bed from wild tracks. It played at three festivals.",
    name: "Théo Marchand",
    role: "Producer",
    company: "Fieldnote",
    avatar: "https://images.pexels.com/photos/33680674/pexels-photo-33680674.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=300&w=300",
    project: "Fieldnote Vol. III",
    rating: 5,
  },
  {
    quote:
      "Twelve verticals, four days, 12 million organic reach. Jules recut each one properly instead of cropping the master — you can feel the difference in the retention graphs.",
    name: "Priya Raman",
    role: "Growth Lead",
    company: "LUMA°",
    avatar: "https://images.pexels.com/photos/35721584/pexels-photo-35721584.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=300&w=300",
    project: "Luma Drop",
    rating: 5,
  },
  {
    quote:
      "I've worked with eleven editors. Jules is the only one who pushed back on my script and was right about it. That's the job. Hire before the calendar fills.",
    name: "Sofia Almeida",
    role: "Director",
    company: "Meridian Films",
    avatar: "https://images.pexels.com/photos/20272960/pexels-photo-20272960.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=300&w=300",
    project: "Hollow Season",
    rating: 5,
  },
  {
    quote:
      "Broadcast delivery used to be my least favourite week. Now it's an email: specs met, QC passed, stems attached. We've put three series through this chair.",
    name: "Elena Cruz",
    role: "Post Supervisor",
    company: "Basecamp Media",
    avatar: "https://images.pexels.com/photos/5725145/pexels-photo-5725145.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=300&w=300",
    project: "Rivet S02",
    rating: 5,
  },
];

export type Tier = {
  id: string;
  name: string;
  kicker: string;
  price: number;
  unit: string;
  best: string;
  featured?: boolean;
  includes: string[];
  not: string;
};

export const TIERS: Tier[] = [
  {
    id: "cutdown",
    name: "Cutdown",
    kicker: "For founders & social teams shipping weekly",
    price: 890,
    unit: "per project",
    best: "1 master + 3 verticals",
    includes: [
      "Up to 6 hours of footage",
      "One 60–90s master + three 9:16 cutdowns",
      "Caption burn-in, 3 languages",
      "2 revision rounds on Frame.io",
      "5 working days to delivery",
      "Web-optimised masters + thumbnails",
    ],
    not: "Color grade beyond shot-match",
  },
  {
    id: "brand",
    name: "Brand Film",
    kicker: "The one most teams actually need",
    price: 3400,
    unit: "per project",
    best: "3–5 min film, full post",
    featured: true,
    includes: [
      "Up to 20 hours of footage ingested & logged",
      "Hero film (3–5 min) + 60s + 15s cutdowns",
      "Full color grade in calibrated suite + LUT bank",
      "Sound design, licensed music & platform-safe mix",
      "Motion titles, lower thirds, end card",
      "3 revision rounds · first cut in 72 hours",
      "10 working days to delivery, all aspect ratios",
      "Project archive + 6-month backup",
    ],
    not: "Shoot-day direction (available as add-on)",
  },
  {
    id: "retainer",
    name: "Series / Retainer",
    kicker: "For teams with a content calendar that never ends",
    price: 6800,
    unit: "per month",
    best: "4 films a month, dedicated chair",
    includes: [
      "Four finished films per month, any length",
      "72-hour first cuts, guaranteed",
      "Unlimited minor revisions inside the month",
      "Shared Slack channel, same-day replies",
      "Post supervision: specs, QC, delivery, archive",
      "Quarterly performance review of what's cutting through",
      "Rolling unused capacity to next month",
    ],
    not: "On-site suite days (quoted separately)",
  },
];

export const ADDONS = [
  { id: "rush", label: "Rush 48h delivery", price: 450, unit: "flat" },
  { id: "subs", label: "Subtitles, 8 languages", price: 220, unit: "flat" },
  { id: "ident", label: "Custom motion ident", price: 600, unit: "flat" },
  { id: "hdr", label: "HDR10 / Dolby pass", price: 750, unit: "flat" },
  { id: "keyart", label: "Key-art & thumbnail set", price: 180, unit: "flat" },
  { id: "onsite", label: "On-site suite day", price: 900, unit: "/day" },
];

export const FAQS = [
  {
    q: "How fast can you actually start?",
    a: "I keep two open slots per month so nothing gets squeezed. Right now the next start date is inside 12 days. If you're genuinely on fire, rush slots exist — they cost more and I'll tell you honestly whether your footage can support the timeline before you commit.",
  },
  {
    q: "What do you need from me on day one?",
    a: "A drive or camera link, the brief (however rough), your brand's type/logo files if there are graphics, and two or three references of work you wish you'd made. That's it. I handle ingest, sync, proxies and logging the same day the footage lands.",
  },
  {
    q: "Do you work with LOG, RAW and multicam?",
    a: "Yes — ARRIRAW, RED, Sony Venice/FX9, Blackmagic BRAW, Canon C-Log, GoPro, iPhone, drone and screen recordings, often in the same timeline. I build a proper colour-managed pipeline so mixed sources match before the creative grade starts.",
  },
  {
    q: "How do revisions work? Am I going to be charged for notes?",
    a: "Notes go on Frame.io, timestamped, in one thread. Three rounds are included on Brand Film and two on Cutdown, and 8 of 10 films lock in two. If you change the brief mid-project — new length, new story, new footage — I'll quote the delta in writing before touching it. No surprise invoices, ever.",
  },
  {
    q: "Can you match the look our brand already has?",
    a: "That's most of the job. Send previous work and I'll reverse-engineer the grade into a reusable LUT bank, then deliver it to you so your in-house team keeps the look consistent long after this project.",
  },
  {
    q: "Who owns the project files and the master?",
    a: "You do, fully, on final payment. You get the master, all cutdowns, stems, graded stills, LUTs and — on request — the Premiere/Resolve project with all media organised. I keep an archive copy for six months so you can come back for re-versioning.",
  },
  {
    q: "What about music licensing and clearances?",
    a: "I source from cleared libraries (Musicbed, Artlist, Soundstripe) or work with your licence. For broadcast or paid media I'll flag anything that needs a sync upgrade before delivery rather than after a takedown. Archive footage and talent releases get checked in the same pass.",
  },
  {
    q: "Can you drop into our existing post team?",
    a: "Often, yes. I regularly work as an additional chair alongside in-house editors — taking the assembly and the grade while your team keeps the client relationship. I work in your Frame.io, your Shotgun, your naming conventions, your Slack.",
  },
];

export const FOOTER_LINKS = {
  Work: [
    { label: "Brand films", href: "#work" },
    { label: "Documentary", href: "#work" },
    { label: "Music video", href: "#work" },
    { label: "Social cutdowns", href: "#work" },
    { label: "The grade bench", href: "#grade" },
  ],
  Studio: [
    { label: "Services", href: "#services" },
    { label: "How we work", href: "#why" },
    { label: "Rates & add-ons", href: "#rates" },
    { label: "FAQ", href: "#faq" },
    { label: "Book a fit call", href: "#book" },
  ],
  Elsewhere: [
    { label: "Vimeo", href: "#book", note: "reel" },
    { label: "Instagram", href: "#book", note: "@jules.cuts" },
    { label: "LinkedIn", href: "#book", note: "/in/julesmercier" },
    { label: "Frame.io", href: "#book", note: "review links" },
    { label: "IMDb", href: "#book", note: "credits" },
  ],
};
